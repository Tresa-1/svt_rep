[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SensitivityLevel](index.md) / [HIGH](./-h-i-g-h.md)

# HIGH

`HIGH`