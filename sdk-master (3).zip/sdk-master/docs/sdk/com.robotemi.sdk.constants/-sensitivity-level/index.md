//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SensitivityLevel](index.md)

# SensitivityLevel

[androidJvm]\
enum [SensitivityLevel](index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[SensitivityLevel](index.md)&gt; 

Sensitivity level.

## Entries

| | |
|---|---|
| [HIGH](-h-i-g-h/index.md) | [androidJvm]<br>[HIGH](-h-i-g-h/index.md) |
| [LOW](-l-o-w/index.md) | [androidJvm]<br>[LOW](-l-o-w/index.md) |

## Properties

| Name | Summary |
|---|---|
| [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
