[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SensitivityLevel](index.md) / [LOW](./-l-o-w.md)

# LOW

`LOW`