//[sdk](../../../../../index.md)/[com.robotemi.sdk.constants](../../../index.md)/[HardButton](../../index.md)/[Mode](../index.md)/[Companion](index.md)/[DEFAULT](-d-e-f-a-u-l-t.md)

# DEFAULT

[androidJvm]\

@[JvmField](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-field/index.html)

val [DEFAULT](-d-e-f-a-u-l-t.md): [HardButton.Mode](../index.md)
