//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[HardButton](index.md)

# HardButton

[androidJvm]\
enum [HardButton](index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[HardButton](index.md)&gt;

## Entries

| | |
|---|---|
| [MAIN](-m-a-i-n/index.md) | [androidJvm]<br>[MAIN](-m-a-i-n/index.md) |
| [POWER](-p-o-w-e-r/index.md) | [androidJvm]<br>[POWER](-p-o-w-e-r/index.md) |
| [VOLUME](-v-o-l-u-m-e/index.md) | [androidJvm]<br>[VOLUME](-v-o-l-u-m-e/index.md) |

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |
| [Mode](-mode/index.md) | [androidJvm]<br>enum [Mode](-mode/index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[HardButton.Mode](-mode/index.md)&gt; |

## Properties

| Name | Summary |
|---|---|
| [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [value](value.md) | [androidJvm]<br>val [value](value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
