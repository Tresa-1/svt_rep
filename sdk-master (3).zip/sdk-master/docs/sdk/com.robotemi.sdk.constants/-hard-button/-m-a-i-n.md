[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [HardButton](index.md) / [MAIN](./-m-a-i-n.md)

# MAIN

`MAIN`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
