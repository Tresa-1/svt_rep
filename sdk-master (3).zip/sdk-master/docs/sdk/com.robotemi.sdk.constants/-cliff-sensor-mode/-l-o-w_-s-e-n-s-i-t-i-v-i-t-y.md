[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [CliffSensorMode](index.md) / [LOW_SENSITIVITY](./-l-o-w_-s-e-n-s-i-t-i-v-i-t-y.md)

# LOW_SENSITIVITY

`LOW_SENSITIVITY`