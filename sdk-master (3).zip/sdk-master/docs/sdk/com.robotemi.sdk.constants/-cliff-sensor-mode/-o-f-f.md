[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [CliffSensorMode](index.md) / [OFF](./-o-f-f.md)

# OFF

`OFF`