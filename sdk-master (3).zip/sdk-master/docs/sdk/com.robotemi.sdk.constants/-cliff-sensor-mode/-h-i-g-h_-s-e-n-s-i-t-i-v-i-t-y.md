[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [CliffSensorMode](index.md) / [HIGH_SENSITIVITY](./-h-i-g-h_-s-e-n-s-i-t-i-v-i-t-y.md)

# HIGH_SENSITIVITY

`HIGH_SENSITIVITY`