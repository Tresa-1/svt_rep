//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[ContentType](index.md)/[path](path.md)

# path

[androidJvm]\
val [path](path.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
