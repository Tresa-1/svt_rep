[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [ContentType](index.md) / [MAP_DATA_IMAGE](./-m-a-p_-d-a-t-a_-i-m-a-g-e.md)

# MAP_DATA_IMAGE

`MAP_DATA_IMAGE`

### Inherited Properties

| Name | Summary |
|---|---|
| [path](path.md) | `val path: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
