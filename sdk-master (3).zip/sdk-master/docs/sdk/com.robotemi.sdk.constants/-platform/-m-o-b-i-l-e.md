[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Platform](index.md) / [MOBILE](./-m-o-b-i-l-e.md)

# MOBILE

`MOBILE`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
