//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[Platform](index.md)

# Platform

[androidJvm]\
enum [Platform](index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[Platform](index.md)&gt;

## Entries

| | |
|---|---|
| [MOBILE](-m-o-b-i-l-e/index.md) | [androidJvm]<br>[MOBILE](-m-o-b-i-l-e/index.md) |
| [TEMI_CENTER](-t-e-m-i_-c-e-n-t-e-r/index.md) | [androidJvm]<br>[TEMI_CENTER](-t-e-m-i_-c-e-n-t-e-r/index.md) |

## Properties

| Name | Summary |
|---|---|
| [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [value](value.md) | [androidJvm]<br>val [value](value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
