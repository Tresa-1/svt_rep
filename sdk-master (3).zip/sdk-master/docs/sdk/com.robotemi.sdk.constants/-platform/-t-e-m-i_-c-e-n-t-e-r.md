[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Platform](index.md) / [TEMI_CENTER](./-t-e-m-i_-c-e-n-t-e-r.md)

# TEMI_CENTER

`TEMI_CENTER`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
