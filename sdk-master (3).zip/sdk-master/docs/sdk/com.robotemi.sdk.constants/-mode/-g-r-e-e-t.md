[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Mode](index.md) / [GREET](./-g-r-e-e-t.md)

# GREET

`GREET`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
