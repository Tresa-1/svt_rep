[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Mode](index.md) / [PRIVACY](./-p-r-i-v-a-c-y.md)

# PRIVACY

`PRIVACY`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
