//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[Mode](index.md)/[value](value.md)

# value

[androidJvm]\
val [value](value.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
