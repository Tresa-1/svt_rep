//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[Utils](index.md)

# Utils

[androidJvm]\
object [Utils](index.md)

## Functions

| Name | Summary |
|---|---|
| [convertBitmapToByteArray](convert-bitmap-to-byte-array.md) | [androidJvm]<br>@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)<br>fun [convertBitmapToByteArray](convert-bitmap-to-byte-array.md)(bitmap: Bitmap): [ByteArray](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-byte-array/index.html) |
