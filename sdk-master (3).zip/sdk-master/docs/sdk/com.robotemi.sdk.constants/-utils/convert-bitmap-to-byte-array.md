//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[Utils](index.md)/[convertBitmapToByteArray](convert-bitmap-to-byte-array.md)

# convertBitmapToByteArray

[androidJvm]\

@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)

fun [convertBitmapToByteArray](convert-bitmap-to-byte-array.md)(bitmap: Bitmap): [ByteArray](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-byte-array/index.html)
