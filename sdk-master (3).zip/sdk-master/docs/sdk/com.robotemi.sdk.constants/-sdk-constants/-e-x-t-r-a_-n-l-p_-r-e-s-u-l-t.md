//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[EXTRA_NLP_RESULT](-e-x-t-r-a_-n-l-p_-r-e-s-u-l-t.md)

# EXTRA_NLP_RESULT

[androidJvm]\
const val [EXTRA_NLP_RESULT](-e-x-t-r-a_-n-l-p_-r-e-s-u-l-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
