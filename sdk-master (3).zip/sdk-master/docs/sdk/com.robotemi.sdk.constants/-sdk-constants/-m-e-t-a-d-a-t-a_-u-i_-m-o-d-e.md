//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_MODE](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e.md)

# METADATA_UI_MODE

[androidJvm]\
const val [METADATA_UI_MODE](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
