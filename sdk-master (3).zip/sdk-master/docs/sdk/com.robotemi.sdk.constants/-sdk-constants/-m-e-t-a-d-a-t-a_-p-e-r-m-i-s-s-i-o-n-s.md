//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_PERMISSIONS](-m-e-t-a-d-a-t-a_-p-e-r-m-i-s-s-i-o-n-s.md)

# METADATA_PERMISSIONS

[androidJvm]\
const val [METADATA_PERMISSIONS](-m-e-t-a-d-a-t-a_-p-e-r-m-i-s-s-i-o-n-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
