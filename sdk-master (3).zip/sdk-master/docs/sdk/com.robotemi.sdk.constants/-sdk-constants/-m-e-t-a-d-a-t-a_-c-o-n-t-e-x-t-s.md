//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_CONTEXTS](-m-e-t-a-d-a-t-a_-c-o-n-t-e-x-t-s.md)

# METADATA_CONTEXTS

[androidJvm]\
const val [METADATA_CONTEXTS](-m-e-t-a-d-a-t-a_-c-o-n-t-e-x-t-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
