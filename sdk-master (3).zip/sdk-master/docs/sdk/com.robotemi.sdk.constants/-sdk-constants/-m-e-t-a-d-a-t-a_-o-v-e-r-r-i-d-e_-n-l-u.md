//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_OVERRIDE_NLU](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-n-l-u.md)

# METADATA_OVERRIDE_NLU

[androidJvm]\
const val [METADATA_OVERRIDE_NLU](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-n-l-u.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
