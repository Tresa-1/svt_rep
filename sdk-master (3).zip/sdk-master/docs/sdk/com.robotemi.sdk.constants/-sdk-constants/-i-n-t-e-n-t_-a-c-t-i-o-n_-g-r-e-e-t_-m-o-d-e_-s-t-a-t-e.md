//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[INTENT_ACTION_GREET_MODE_STATE](-i-n-t-e-n-t_-a-c-t-i-o-n_-g-r-e-e-t_-m-o-d-e_-s-t-a-t-e.md)

# INTENT_ACTION_GREET_MODE_STATE

[androidJvm]\
const val [INTENT_ACTION_GREET_MODE_STATE](-i-n-t-e-n-t_-a-c-t-i-o-n_-g-r-e-e-t_-m-o-d-e_-s-t-a-t-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
