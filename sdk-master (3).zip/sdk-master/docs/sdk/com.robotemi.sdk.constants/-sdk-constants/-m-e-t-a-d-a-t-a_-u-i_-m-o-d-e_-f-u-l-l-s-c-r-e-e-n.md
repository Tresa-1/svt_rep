//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_MODE_FULLSCREEN](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-f-u-l-l-s-c-r-e-e-n.md)

# METADATA_UI_MODE_FULLSCREEN

[androidJvm]\
const val [METADATA_UI_MODE_FULLSCREEN](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-f-u-l-l-s-c-r-e-e-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1

All UI elements are hidden. If this mode is set other Flags are ignored. `R.integer.metadata_ui_mode_fullscreen`
