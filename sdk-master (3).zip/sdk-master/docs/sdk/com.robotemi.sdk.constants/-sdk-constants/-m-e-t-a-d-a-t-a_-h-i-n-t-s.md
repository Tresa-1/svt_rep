//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_HINTS](-m-e-t-a-d-a-t-a_-h-i-n-t-s.md)

# METADATA_HINTS

[androidJvm]\
const val [METADATA_HINTS](-m-e-t-a-d-a-t-a_-h-i-n-t-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
