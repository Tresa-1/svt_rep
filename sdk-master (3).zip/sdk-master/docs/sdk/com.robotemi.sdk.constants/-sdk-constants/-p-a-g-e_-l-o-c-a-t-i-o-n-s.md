//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PAGE_LOCATIONS](-p-a-g-e_-l-o-c-a-t-i-o-n-s.md)

# PAGE_LOCATIONS

[androidJvm]\
const val [PAGE_LOCATIONS](-p-a-g-e_-l-o-c-a-t-i-o-n-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
