//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[TRUE](-t-r-u-e.md)

# TRUE

[androidJvm]\
const val [TRUE](-t-r-u-e.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1
