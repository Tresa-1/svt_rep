//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PAGE_CONTACTS](-p-a-g-e_-c-o-n-t-a-c-t-s.md)

# PAGE_CONTACTS

[androidJvm]\
const val [PAGE_CONTACTS](-p-a-g-e_-c-o-n-t-a-c-t-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
