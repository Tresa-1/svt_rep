//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_ASSISTANT](-m-e-t-a-d-a-t-a_-a-s-s-i-s-t-a-n-t.md)

# METADATA_ASSISTANT

[androidJvm]\
const val [METADATA_ASSISTANT](-m-e-t-a-d-a-t-a_-a-s-s-i-s-t-a-n-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
