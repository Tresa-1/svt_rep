//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_MODE_IMMERSIVE](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-i-m-m-e-r-s-i-v-e.md)

# METADATA_UI_MODE_IMMERSIVE

[androidJvm]\
const val [METADATA_UI_MODE_IMMERSIVE](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-i-m-m-e-r-s-i-v-e.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2

UI elements can be shown/hidden when requested. This mode can be used in conjunction with Flags. `R.integer.metadata_ui_mode_immersive`
