//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_OVERRIDE_CONVERSATION_LAYER](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-c-o-n-v-e-r-s-a-t-i-o-n_-l-a-y-e-r.md)

# METADATA_OVERRIDE_CONVERSATION_LAYER

[androidJvm]\
const val [METADATA_OVERRIDE_CONVERSATION_LAYER](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-c-o-n-v-e-r-s-a-t-i-o-n_-l-a-y-e-r.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
