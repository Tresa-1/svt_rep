//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_KIOSK](-m-e-t-a-d-a-t-a_-k-i-o-s-k.md)

# METADATA_KIOSK

[androidJvm]\
const val [METADATA_KIOSK](-m-e-t-a-d-a-t-a_-k-i-o-s-k.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
