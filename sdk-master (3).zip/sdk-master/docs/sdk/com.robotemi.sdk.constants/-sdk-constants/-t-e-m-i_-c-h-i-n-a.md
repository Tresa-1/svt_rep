//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[TEMI_CHINA](-t-e-m-i_-c-h-i-n-a.md)

# TEMI_CHINA

[androidJvm]\
const val [TEMI_CHINA](-t-e-m-i_-c-h-i-n-a.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
