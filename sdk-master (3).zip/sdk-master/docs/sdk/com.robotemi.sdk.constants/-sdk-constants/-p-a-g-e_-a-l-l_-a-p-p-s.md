//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PAGE_ALL_APPS](-p-a-g-e_-a-l-l_-a-p-p-s.md)

# PAGE_ALL_APPS

[androidJvm]\
const val [PAGE_ALL_APPS](-p-a-g-e_-a-l-l_-a-p-p-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
