//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[BACK](-b-a-c-k.md)

# BACK

[androidJvm]\
const val [BACK](-b-a-c-k.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
