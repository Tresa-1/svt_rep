//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[NOT_SET](-n-o-t_-s-e-t.md)

# NOT_SET

[androidJvm]\
const val [NOT_SET](-n-o-t_-s-e-t.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0
