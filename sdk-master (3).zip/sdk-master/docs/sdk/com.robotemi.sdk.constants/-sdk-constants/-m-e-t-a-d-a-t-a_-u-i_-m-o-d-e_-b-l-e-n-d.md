//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_MODE_BLEND](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-b-l-e-n-d.md)

# METADATA_UI_MODE_BLEND

[androidJvm]\
const val [METADATA_UI_MODE_BLEND](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-b-l-e-n-d.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 3

All UI elements are visible. If this mode is set other Flags are ignored. `R.integer.metadata_ui_mode_blend`
