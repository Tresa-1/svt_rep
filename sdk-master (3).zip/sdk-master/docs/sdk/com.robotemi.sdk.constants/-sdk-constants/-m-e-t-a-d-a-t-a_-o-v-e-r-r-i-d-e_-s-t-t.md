//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_OVERRIDE_STT](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-s-t-t.md)

# METADATA_OVERRIDE_STT

[androidJvm]\
const val [METADATA_OVERRIDE_STT](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-s-t-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
