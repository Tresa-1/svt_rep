//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_FLAG_HIDE_TOP_BAR](-m-e-t-a-d-a-t-a_-u-i_-f-l-a-g_-h-i-d-e_-t-o-p_-b-a-r.md)

# METADATA_UI_FLAG_HIDE_TOP_BAR

[androidJvm]\
const val [METADATA_UI_FLAG_HIDE_TOP_BAR](-m-e-t-a-d-a-t-a_-u-i_-f-l-a-g_-h-i-d-e_-t-o-p_-b-a-r.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1

Hide top bar always. `R.integer.metadata_ui_flag_hide_top_bar`
