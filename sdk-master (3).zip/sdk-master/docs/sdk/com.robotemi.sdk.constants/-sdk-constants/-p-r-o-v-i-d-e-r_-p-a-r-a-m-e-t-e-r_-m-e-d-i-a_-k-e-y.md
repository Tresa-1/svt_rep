//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PROVIDER_PARAMETER_MEDIA_KEY](-p-r-o-v-i-d-e-r_-p-a-r-a-m-e-t-e-r_-m-e-d-i-a_-k-e-y.md)

# PROVIDER_PARAMETER_MEDIA_KEY

[androidJvm]\
const val [PROVIDER_PARAMETER_MEDIA_KEY](-p-r-o-v-i-d-e-r_-p-a-r-a-m-e-t-e-r_-m-e-d-i-a_-k-e-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
