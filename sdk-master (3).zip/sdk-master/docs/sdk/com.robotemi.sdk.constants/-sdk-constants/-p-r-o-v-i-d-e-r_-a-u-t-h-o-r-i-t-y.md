//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PROVIDER_AUTHORITY](-p-r-o-v-i-d-e-r_-a-u-t-h-o-r-i-t-y.md)

# PROVIDER_AUTHORITY

[androidJvm]\
const val [PROVIDER_AUTHORITY](-p-r-o-v-i-d-e-r_-a-u-t-h-o-r-i-t-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
