//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[LOCATION_HOME_BASE](-l-o-c-a-t-i-o-n_-h-o-m-e_-b-a-s-e.md)

# LOCATION_HOME_BASE

[androidJvm]\
const val [LOCATION_HOME_BASE](-l-o-c-a-t-i-o-n_-h-o-m-e_-b-a-s-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
