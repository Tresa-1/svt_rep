//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_MODE_HIDE_ALL_TOP_BAR_ELEMENTS](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-h-i-d-e_-a-l-l_-t-o-p_-b-a-r_-e-l-e-m-e-n-t-s.md)

# METADATA_UI_MODE_HIDE_ALL_TOP_BAR_ELEMENTS

[androidJvm]\
const val [METADATA_UI_MODE_HIDE_ALL_TOP_BAR_ELEMENTS](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-h-i-d-e_-a-l-l_-t-o-p_-b-a-r_-e-l-e-m-e-n-t-s.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 4
