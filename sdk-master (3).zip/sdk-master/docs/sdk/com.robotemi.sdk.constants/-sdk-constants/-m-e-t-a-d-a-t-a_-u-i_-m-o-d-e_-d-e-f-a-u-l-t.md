//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_UI_MODE_DEFAULT](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-d-e-f-a-u-l-t.md)

# METADATA_UI_MODE_DEFAULT

[androidJvm]\
const val [METADATA_UI_MODE_DEFAULT](-m-e-t-a-d-a-t-a_-u-i_-m-o-d-e_-d-e-f-a-u-l-t.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0

All UI elements are visible. If this mode is set other Flags are ignored. `R.integer.metadata_ui_mode_default`
