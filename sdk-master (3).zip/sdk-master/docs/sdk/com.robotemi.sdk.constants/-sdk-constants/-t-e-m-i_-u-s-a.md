//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[TEMI_USA](-t-e-m-i_-u-s-a.md)

# TEMI_USA

[androidJvm]\
const val [TEMI_USA](-t-e-m-i_-u-s-a.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
