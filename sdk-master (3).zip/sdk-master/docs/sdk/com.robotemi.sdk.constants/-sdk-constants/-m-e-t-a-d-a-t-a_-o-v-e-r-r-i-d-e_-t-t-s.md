//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_OVERRIDE_TTS](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-t-t-s.md)

# METADATA_OVERRIDE_TTS

[androidJvm]\
const val [METADATA_OVERRIDE_TTS](-m-e-t-a-d-a-t-a_-o-v-e-r-r-i-d-e_-t-t-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
