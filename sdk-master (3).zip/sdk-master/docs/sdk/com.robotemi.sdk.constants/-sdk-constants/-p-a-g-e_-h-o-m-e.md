//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PAGE_HOME](-p-a-g-e_-h-o-m-e.md)

# PAGE_HOME

[androidJvm]\
const val [PAGE_HOME](-p-a-g-e_-h-o-m-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
