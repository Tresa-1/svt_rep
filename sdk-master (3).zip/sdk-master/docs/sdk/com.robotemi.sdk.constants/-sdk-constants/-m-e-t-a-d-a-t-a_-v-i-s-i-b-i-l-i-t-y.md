//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_VISIBILITY](-m-e-t-a-d-a-t-a_-v-i-s-i-b-i-l-i-t-y.md)

# METADATA_VISIBILITY

[androidJvm]\
const val [METADATA_VISIBILITY](-m-e-t-a-d-a-t-a_-v-i-s-i-b-i-l-i-t-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
