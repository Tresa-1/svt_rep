//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_ACTIONS](-m-e-t-a-d-a-t-a_-a-c-t-i-o-n-s.md)

# METADATA_ACTIONS

[androidJvm]\
const val [METADATA_ACTIONS](-m-e-t-a-d-a-t-a_-a-c-t-i-o-n-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
