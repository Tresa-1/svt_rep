//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PAGE_MAP_EDITOR](-p-a-g-e_-m-a-p_-e-d-i-t-o-r.md)

# PAGE_MAP_EDITOR

[androidJvm]\
const val [PAGE_MAP_EDITOR](-p-a-g-e_-m-a-p_-e-d-i-t-o-r.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
