//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PROVIDER_PARAMETER_MAP_DATA](-p-r-o-v-i-d-e-r_-p-a-r-a-m-e-t-e-r_-m-a-p_-d-a-t-a.md)

# PROVIDER_PARAMETER_MAP_DATA

[androidJvm]\
const val [PROVIDER_PARAMETER_MAP_DATA](-p-r-o-v-i-d-e-r_-p-a-r-a-m-e-t-e-r_-m-a-p_-d-a-t-a.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
