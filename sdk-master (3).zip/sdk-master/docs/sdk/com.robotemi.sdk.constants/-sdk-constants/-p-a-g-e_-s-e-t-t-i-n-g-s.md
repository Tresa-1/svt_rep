//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[PAGE_SETTINGS](-p-a-g-e_-s-e-t-t-i-n-g-s.md)

# PAGE_SETTINGS

[androidJvm]\
const val [PAGE_SETTINGS](-p-a-g-e_-s-e-t-t-i-n-g-s.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
