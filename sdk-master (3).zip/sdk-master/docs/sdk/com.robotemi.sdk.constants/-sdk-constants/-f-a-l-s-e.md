//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[FALSE](-f-a-l-s-e.md)

# FALSE

[androidJvm]\
const val [FALSE](-f-a-l-s-e.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
