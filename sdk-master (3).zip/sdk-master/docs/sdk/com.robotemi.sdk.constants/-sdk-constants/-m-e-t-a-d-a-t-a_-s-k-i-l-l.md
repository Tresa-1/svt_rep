//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_SKILL](-m-e-t-a-d-a-t-a_-s-k-i-l-l.md)

# METADATA_SKILL

[androidJvm]\
const val [METADATA_SKILL](-m-e-t-a-d-a-t-a_-s-k-i-l-l.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
