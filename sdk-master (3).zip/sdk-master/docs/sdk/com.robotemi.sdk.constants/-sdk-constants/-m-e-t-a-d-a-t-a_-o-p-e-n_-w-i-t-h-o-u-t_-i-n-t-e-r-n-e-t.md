//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[METADATA_OPEN_WITHOUT_INTERNET](-m-e-t-a-d-a-t-a_-o-p-e-n_-w-i-t-h-o-u-t_-i-n-t-e-r-n-e-t.md)

# METADATA_OPEN_WITHOUT_INTERNET

[androidJvm]\
const val [METADATA_OPEN_WITHOUT_INTERNET](-m-e-t-a-d-a-t-a_-o-p-e-n_-w-i-t-h-o-u-t_-i-n-t-e-r-n-e-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
