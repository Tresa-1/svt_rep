//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[SdkConstants](index.md)/[DETECTION_DISTANCE_DEFAULT](-d-e-t-e-c-t-i-o-n_-d-i-s-t-a-n-c-e_-d-e-f-a-u-l-t.md)

# DETECTION_DISTANCE_DEFAULT

[androidJvm]\
const val [DETECTION_DISTANCE_DEFAULT](-d-e-t-e-c-t-i-o-n_-d-i-s-t-a-n-c-e_-d-e-f-a-u-l-t.md): [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html) = 0.8f
