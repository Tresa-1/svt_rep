[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SequenceCommand](index.md) / [STOP](./-s-t-o-p.md)

# STOP

`STOP`