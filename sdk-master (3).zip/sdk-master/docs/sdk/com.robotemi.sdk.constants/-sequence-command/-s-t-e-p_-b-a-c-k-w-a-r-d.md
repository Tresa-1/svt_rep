[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SequenceCommand](index.md) / [STEP_BACKWARD](./-s-t-e-p_-b-a-c-k-w-a-r-d.md)

# STEP_BACKWARD

`STEP_BACKWARD`