[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SequenceCommand](index.md) / [PLAY](./-p-l-a-y.md)

# PLAY

`PLAY`