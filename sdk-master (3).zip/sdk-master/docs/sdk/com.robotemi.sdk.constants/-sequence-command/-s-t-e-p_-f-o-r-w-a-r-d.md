[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SequenceCommand](index.md) / [STEP_FORWARD](./-s-t-e-p_-f-o-r-w-a-r-d.md)

# STEP_FORWARD

`STEP_FORWARD`