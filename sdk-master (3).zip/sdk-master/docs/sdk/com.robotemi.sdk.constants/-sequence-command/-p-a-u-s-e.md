[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SequenceCommand](index.md) / [PAUSE](./-p-a-u-s-e.md)

# PAUSE

`PAUSE`