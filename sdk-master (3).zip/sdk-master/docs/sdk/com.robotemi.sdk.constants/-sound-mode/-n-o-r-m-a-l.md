[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SoundMode](index.md) / [NORMAL](./-n-o-r-m-a-l.md)

# NORMAL

`NORMAL`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
