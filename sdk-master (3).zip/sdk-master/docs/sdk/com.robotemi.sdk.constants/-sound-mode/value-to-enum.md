[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SoundMode](index.md) / [valueToEnum](./value-to-enum.md)

# valueToEnum

`@JvmStatic fun valueToEnum(value: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`SoundMode`](index.md)