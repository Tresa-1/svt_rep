[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [SoundMode](index.md) / [DEFAULT](./-d-e-f-a-u-l-t.md)

# DEFAULT

`val DEFAULT: `[`SoundMode`](index.md)