[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Page](index.md) / [ALL_APPS](./-a-l-l_-a-p-p-s.md)

# ALL_APPS

`ALL_APPS`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
