[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Page](index.md) / [HOME](./-h-o-m-e.md)

# HOME

`HOME`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
