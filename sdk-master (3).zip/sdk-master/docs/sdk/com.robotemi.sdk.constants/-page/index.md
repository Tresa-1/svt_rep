//[sdk](../../../index.md)/[com.robotemi.sdk.constants](../index.md)/[Page](index.md)

# Page

[androidJvm]\
enum [Page](index.md) : [Enum](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-enum/index.html)&lt;[Page](index.md)&gt;

## Entries

| | |
|---|---|
| [SETTINGS](-s-e-t-t-i-n-g-s/index.md) | [androidJvm]<br>[SETTINGS](-s-e-t-t-i-n-g-s/index.md) |
| [MAP_EDITOR](-m-a-p_-e-d-i-t-o-r/index.md) | [androidJvm]<br>[MAP_EDITOR](-m-a-p_-e-d-i-t-o-r/index.md) |
| [CONTACTS](-c-o-n-t-a-c-t-s/index.md) | [androidJvm]<br>[CONTACTS](-c-o-n-t-a-c-t-s/index.md) |
| [LOCATIONS](-l-o-c-a-t-i-o-n-s/index.md) | [androidJvm]<br>[LOCATIONS](-l-o-c-a-t-i-o-n-s/index.md) |
| [ALL_APPS](-a-l-l_-a-p-p-s/index.md) | [androidJvm]<br>[ALL_APPS](-a-l-l_-a-p-p-s/index.md) |
| [HOME](-h-o-m-e/index.md) | [androidJvm]<br>[HOME](-h-o-m-e/index.md) |

## Properties

| Name | Summary |
|---|---|
| [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411) | [androidJvm]<br>val [name](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-372974862%2FProperties%2F462465411): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411) | [androidJvm]<br>val [ordinal](../../com.robotemi.sdk.permission/-permission/-u-n-k-n-o-w-n/index.md#-739389684%2FProperties%2F462465411): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [value](value.md) | [androidJvm]<br>val [value](value.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
