[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Page](index.md) / [MAP_EDITOR](./-m-a-p_-e-d-i-t-o-r.md)

# MAP_EDITOR

`MAP_EDITOR`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
