[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Page](index.md) / [LOCATIONS](./-l-o-c-a-t-i-o-n-s.md)

# LOCATIONS

`LOCATIONS`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
