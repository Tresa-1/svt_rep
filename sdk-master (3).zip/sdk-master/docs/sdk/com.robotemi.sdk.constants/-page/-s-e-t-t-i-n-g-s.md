[sdk](../../index.md) / [com.robotemi.sdk.constants](../index.md) / [Page](index.md) / [SETTINGS](./-s-e-t-t-i-n-g-s.md)

# SETTINGS

`SETTINGS`

### Inherited Properties

| Name | Summary |
|---|---|
| [value](value.md) | `val value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
