//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Layer](index.md)/[Layer](-layer.md)

# Layer

[androidJvm]\
fun [Layer](-layer.md)(parcel: Parcel)

fun [Layer](-layer.md)(layerCreationUTC: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), layerCategory: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), layerId: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, layerThickness: [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html), layerStatus: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), layerPoses: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[LayerPose](../-layer-pose/index.md)&gt;?)
