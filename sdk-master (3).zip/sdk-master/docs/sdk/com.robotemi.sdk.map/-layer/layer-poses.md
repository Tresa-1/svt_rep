//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Layer](index.md)/[layerPoses](layer-poses.md)

# layerPoses

[androidJvm]\

@SerializedName(value = &quot;layer_poses&quot;)

val [layerPoses](layer-poses.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[LayerPose](../-layer-pose/index.md)&gt;?
