//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Layer](index.md)/[layerCategory](layer-category.md)

# layerCategory

[androidJvm]\

@SerializedName(value = &quot;layer_category&quot;)

val [layerCategory](layer-category.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
