//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Layer](index.md)/[layerCreationUTC](layer-creation-u-t-c.md)

# layerCreationUTC

[androidJvm]\

@SerializedName(value = &quot;layer_creation_universal_time&quot;)

val [layerCreationUTC](layer-creation-u-t-c.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
