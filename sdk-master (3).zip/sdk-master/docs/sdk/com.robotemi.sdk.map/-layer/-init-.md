[sdk](../../index.md) / [com.robotemi.sdk.map](../index.md) / [Layer](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Layer(parcel: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`)`
`Layer(layerCreationUTC: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, layerCategory: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, layerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", layerThickness: `[`Float`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)`, layerStatus: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, layerPoses: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`LayerPose`](../-layer-pose/index.md)`>?)`