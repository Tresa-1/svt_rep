//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Layer](index.md)/[layerId](layer-id.md)

# layerId

[androidJvm]\

@SerializedName(value = &quot;layer_id&quot;)

val [layerId](layer-id.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
