//[sdk](../../index.md)/[com.robotemi.sdk.map](index.md)/[LOCATION](-l-o-c-a-t-i-o-n.md)

# LOCATION

[androidJvm]\
const val [LOCATION](-l-o-c-a-t-i-o-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 4
