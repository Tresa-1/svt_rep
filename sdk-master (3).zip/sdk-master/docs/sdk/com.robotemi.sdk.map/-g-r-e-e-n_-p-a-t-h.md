//[sdk](../../index.md)/[com.robotemi.sdk.map](index.md)/[GREEN_PATH](-g-r-e-e-n_-p-a-t-h.md)

# GREEN_PATH

[androidJvm]\
const val [GREEN_PATH](-g-r-e-e-n_-p-a-t-h.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0
