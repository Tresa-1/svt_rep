[sdk](../../index.md) / [com.robotemi.sdk.map](../index.md) / [Floor](index.md) / [createFromParcel](./create-from-parcel.md)

# createFromParcel

`fun createFromParcel(parcel: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`): `[`Floor`](index.md)