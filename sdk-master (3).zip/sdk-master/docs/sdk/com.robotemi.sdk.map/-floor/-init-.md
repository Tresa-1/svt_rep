[sdk](../../index.md) / [com.robotemi.sdk.map](../index.md) / [Floor](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Floor(parcel: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`)`
`Floor(id: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = -1, name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", mapId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", data: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "")`