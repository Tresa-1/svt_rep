[sdk](../../index.md) / [com.robotemi.sdk.map](../index.md) / [Floor](index.md) / [newArray](./new-array.md)

# newArray

`fun newArray(size: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`Array`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)`<`[`Floor`](index.md)`?>`