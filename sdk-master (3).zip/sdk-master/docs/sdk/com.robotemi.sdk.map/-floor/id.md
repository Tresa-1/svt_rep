//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Floor](index.md)/[id](id.md)

# id

[androidJvm]\
val [id](id.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
