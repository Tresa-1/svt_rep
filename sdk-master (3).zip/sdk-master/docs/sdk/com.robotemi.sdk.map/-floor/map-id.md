//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Floor](index.md)/[mapId](map-id.md)

# mapId

[androidJvm]\
val [mapId](map-id.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
