//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Floor](index.md)/[Floor](-floor.md)

# Floor

[androidJvm]\
fun [Floor](-floor.md)(parcel: Parcel)

fun [Floor](-floor.md)(id: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = -1, name: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, mapId: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, data: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;)
