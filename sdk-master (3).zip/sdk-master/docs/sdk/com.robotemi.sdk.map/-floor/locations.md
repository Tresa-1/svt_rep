//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[Floor](index.md)/[locations](locations.md)

# locations

[androidJvm]\
val [locations](locations.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[Location](../-location/index.md)&gt;
