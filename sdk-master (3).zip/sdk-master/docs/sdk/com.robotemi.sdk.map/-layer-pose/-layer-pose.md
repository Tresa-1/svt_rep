//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[LayerPose](index.md)/[LayerPose](-layer-pose.md)

# LayerPose

[androidJvm]\
fun [LayerPose](-layer-pose.md)(parcel: Parcel)

fun [LayerPose](-layer-pose.md)(x: [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html), y: [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html), theta: [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html))
