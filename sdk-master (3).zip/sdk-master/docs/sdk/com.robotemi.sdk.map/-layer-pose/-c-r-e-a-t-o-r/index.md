//[sdk](../../../../index.md)/[com.robotemi.sdk.map](../../index.md)/[LayerPose](../index.md)/[CREATOR](index.md)

# CREATOR

[androidJvm]\
object [CREATOR](index.md) : Parcelable.Creator&lt;[LayerPose](../index.md)&gt;

## Functions

| Name | Summary |
|---|---|
| [createFromParcel](create-from-parcel.md) | [androidJvm]<br>open override fun [createFromParcel](create-from-parcel.md)(parcel: Parcel): [LayerPose](../index.md) |
| [newArray](new-array.md) | [androidJvm]<br>open override fun [newArray](new-array.md)(size: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)): [Array](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)&lt;[LayerPose](../index.md)?&gt; |
