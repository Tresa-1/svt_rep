//[sdk](../../../../index.md)/[com.robotemi.sdk.map](../../index.md)/[LayerPose](../index.md)/[CREATOR](index.md)/[createFromParcel](create-from-parcel.md)

# createFromParcel

[androidJvm]\
open override fun [createFromParcel](create-from-parcel.md)(parcel: Parcel): [LayerPose](../index.md)
