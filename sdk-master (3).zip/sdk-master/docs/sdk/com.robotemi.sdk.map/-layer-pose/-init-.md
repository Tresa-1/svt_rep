[sdk](../../index.md) / [com.robotemi.sdk.map](../index.md) / [LayerPose](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`LayerPose(parcel: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`)`
`LayerPose(x: `[`Float`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)`, y: `[`Float`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)`, theta: `[`Float`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)`)`