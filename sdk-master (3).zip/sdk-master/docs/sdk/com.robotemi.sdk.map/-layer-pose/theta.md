//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[LayerPose](index.md)/[theta](theta.md)

# theta

[androidJvm]\

@SerializedName(value = &quot;theta&quot;)

val [theta](theta.md): [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)
