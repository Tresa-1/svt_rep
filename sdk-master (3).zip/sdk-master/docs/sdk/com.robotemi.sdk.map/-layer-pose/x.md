//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[LayerPose](index.md)/[x](x.md)

# x

[androidJvm]\

@SerializedName(value = &quot;x&quot;)

val [x](x.md): [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)
