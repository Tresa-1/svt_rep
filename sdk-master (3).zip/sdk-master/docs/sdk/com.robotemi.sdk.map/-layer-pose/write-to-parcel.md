//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[LayerPose](index.md)/[writeToParcel](write-to-parcel.md)

# writeToParcel

[androidJvm]\
open override fun [writeToParcel](write-to-parcel.md)(parcel: Parcel, flags: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
