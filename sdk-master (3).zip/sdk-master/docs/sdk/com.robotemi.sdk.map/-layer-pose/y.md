//[sdk](../../../index.md)/[com.robotemi.sdk.map](../index.md)/[LayerPose](index.md)/[y](y.md)

# y

[androidJvm]\

@SerializedName(value = &quot;y&quot;)

val [y](y.md): [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)
