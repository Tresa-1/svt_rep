//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnConstraintBeWithStatusChangedListener](index.md)

# OnConstraintBeWithStatusChangedListener

[androidJvm]\
interface [OnConstraintBeWithStatusChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onConstraintBeWithStatusChanged](on-constraint-be-with-status-changed.md) | [androidJvm]<br>abstract fun [onConstraintBeWithStatusChanged](on-constraint-be-with-status-changed.md)(isConstraint: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))<br>Listen for Constraint Follow state. |
