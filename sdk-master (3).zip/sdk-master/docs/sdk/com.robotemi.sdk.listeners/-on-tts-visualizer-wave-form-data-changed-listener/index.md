//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTtsVisualizerWaveFormDataChangedListener](index.md)

# OnTtsVisualizerWaveFormDataChangedListener

[androidJvm]\
interface [OnTtsVisualizerWaveFormDataChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onTtsVisualizerWaveFormDataChanged](on-tts-visualizer-wave-form-data-changed.md) | [androidJvm]<br>abstract fun [onTtsVisualizerWaveFormDataChanged](on-tts-visualizer-wave-form-data-changed.md)(waveForm: [ByteArray](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-byte-array/index.html)) |
