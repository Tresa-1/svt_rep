//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTtsVisualizerWaveFormDataChangedListener](index.md)/[onTtsVisualizerWaveFormDataChanged](on-tts-visualizer-wave-form-data-changed.md)

# onTtsVisualizerWaveFormDataChanged

[androidJvm]\
abstract fun [onTtsVisualizerWaveFormDataChanged](on-tts-visualizer-wave-form-data-changed.md)(waveForm: [ByteArray](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-byte-array/index.html))
