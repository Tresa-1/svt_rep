//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnPrivacyModeChangedListener](index.md)/[onPrivacyModeChanged](on-privacy-mode-changed.md)

# onPrivacyModeChanged

[androidJvm]\
abstract fun [onPrivacyModeChanged](on-privacy-mode-changed.md)(state: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))

Called when privacy mode state changes (true = privacy mode on, false = off).
