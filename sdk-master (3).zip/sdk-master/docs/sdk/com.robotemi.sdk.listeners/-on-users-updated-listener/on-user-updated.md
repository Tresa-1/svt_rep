//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnUsersUpdatedListener](index.md)/[onUserUpdated](on-user-updated.md)

# onUserUpdated

[androidJvm]\
abstract fun [onUserUpdated](on-user-updated.md)(user: [UserInfo](../../com.robotemi.sdk/-user-info/index.md))

Called when users info was changed.
