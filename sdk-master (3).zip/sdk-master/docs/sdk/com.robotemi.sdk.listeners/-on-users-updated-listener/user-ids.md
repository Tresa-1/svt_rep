//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnUsersUpdatedListener](index.md)/[userIds](user-ids.md)

# userIds

[androidJvm]\
var [userIds](user-ids.md): [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;?
