[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnUsersUpdatedListener](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`OnUsersUpdatedListener(userIds: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`>?)`