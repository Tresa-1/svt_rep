//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnRobotLiftedListener](index.md)/[onRobotLifted](on-robot-lifted.md)

# onRobotLifted

[androidJvm]\
abstract fun [onRobotLifted](on-robot-lifted.md)(isLifted: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html), reason: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))
