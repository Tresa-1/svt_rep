//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTelepresenceEventChangedListener](index.md)/[onTelepresenceEventChanged](on-telepresence-event-changed.md)

# onTelepresenceEventChanged

[androidJvm]\
abstract fun [onTelepresenceEventChanged](on-telepresence-event-changed.md)(callEventModel: [CallEventModel](../../com.robotemi.sdk.model/-call-event-model/index.md))

Available event:

## Parameters

androidJvm

| | |
|---|---|
| callEventModel | Call info. |
