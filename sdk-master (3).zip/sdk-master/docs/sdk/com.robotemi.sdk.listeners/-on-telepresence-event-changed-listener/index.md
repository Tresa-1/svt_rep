//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTelepresenceEventChangedListener](index.md)

# OnTelepresenceEventChangedListener

[androidJvm]\
interface [OnTelepresenceEventChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onTelepresenceEventChanged](on-telepresence-event-changed.md) | [androidJvm]<br>abstract fun [onTelepresenceEventChanged](on-telepresence-event-changed.md)(callEventModel: [CallEventModel](../../com.robotemi.sdk.model/-call-event-model/index.md))<br>Available event: |
