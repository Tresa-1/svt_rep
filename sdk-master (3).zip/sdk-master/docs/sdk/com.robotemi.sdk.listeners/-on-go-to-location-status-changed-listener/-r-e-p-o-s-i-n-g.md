[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGoToLocationStatusChangedListener](index.md) / [REPOSING](./-r-e-p-o-s-i-n-g.md)

# REPOSING

`const val REPOSING: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)