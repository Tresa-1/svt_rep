[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGoToLocationStatusChangedListener](index.md) / [START](./-s-t-a-r-t.md)

# START

`const val START: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)