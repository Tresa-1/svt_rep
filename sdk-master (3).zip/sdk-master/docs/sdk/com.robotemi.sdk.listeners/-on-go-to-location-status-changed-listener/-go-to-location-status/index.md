//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[GoToLocationStatus](index.md)

# GoToLocationStatus

[androidJvm]\
annotation class [GoToLocationStatus](index.md)

## Constructors

| | |
|---|---|
| [GoToLocationStatus](-go-to-location-status.md) | [androidJvm]<br>fun [GoToLocationStatus](-go-to-location-status.md)() |
