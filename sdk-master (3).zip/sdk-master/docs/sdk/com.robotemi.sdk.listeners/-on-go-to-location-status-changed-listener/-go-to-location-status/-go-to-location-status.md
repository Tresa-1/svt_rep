//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[GoToLocationStatus](index.md)/[GoToLocationStatus](-go-to-location-status.md)

# GoToLocationStatus

[androidJvm]\
fun [GoToLocationStatus](-go-to-location-status.md)()
