[sdk](../../../index.md) / [com.robotemi.sdk.listeners](../../index.md) / [OnGoToLocationStatusChangedListener](../index.md) / [GoToLocationStatus](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`GoToLocationStatus()`