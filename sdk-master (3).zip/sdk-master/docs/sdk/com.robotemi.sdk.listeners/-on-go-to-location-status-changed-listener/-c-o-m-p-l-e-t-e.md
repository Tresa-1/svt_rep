[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGoToLocationStatusChangedListener](index.md) / [COMPLETE](./-c-o-m-p-l-e-t-e.md)

# COMPLETE

`const val COMPLETE: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)