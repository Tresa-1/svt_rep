[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGoToLocationStatusChangedListener](index.md) / [GOING](./-g-o-i-n-g.md)

# GOING

`const val GOING: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)