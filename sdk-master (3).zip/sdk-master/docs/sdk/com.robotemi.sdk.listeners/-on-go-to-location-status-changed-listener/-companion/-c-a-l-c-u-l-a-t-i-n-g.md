//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[Companion](index.md)/[CALCULATING](-c-a-l-c-u-l-a-t-i-n-g.md)

# CALCULATING

[androidJvm]\
const val [CALCULATING](-c-a-l-c-u-l-a-t-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
