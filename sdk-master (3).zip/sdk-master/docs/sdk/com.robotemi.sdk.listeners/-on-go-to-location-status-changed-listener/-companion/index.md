//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [ABORT](-a-b-o-r-t.md) | [androidJvm]<br>const val [ABORT](-a-b-o-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [CALCULATING](-c-a-l-c-u-l-a-t-i-n-g.md) | [androidJvm]<br>const val [CALCULATING](-c-a-l-c-u-l-a-t-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [COMPLETE](-c-o-m-p-l-e-t-e.md) | [androidJvm]<br>const val [COMPLETE](-c-o-m-p-l-e-t-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [GOING](-g-o-i-n-g.md) | [androidJvm]<br>const val [GOING](-g-o-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [REPOSING](-r-e-p-o-s-i-n-g.md) | [androidJvm]<br>const val [REPOSING](-r-e-p-o-s-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [START](-s-t-a-r-t.md) | [androidJvm]<br>const val [START](-s-t-a-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
