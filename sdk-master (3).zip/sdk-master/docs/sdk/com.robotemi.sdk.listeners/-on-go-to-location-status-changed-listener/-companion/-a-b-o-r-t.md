//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[Companion](index.md)/[ABORT](-a-b-o-r-t.md)

# ABORT

[androidJvm]\
const val [ABORT](-a-b-o-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
