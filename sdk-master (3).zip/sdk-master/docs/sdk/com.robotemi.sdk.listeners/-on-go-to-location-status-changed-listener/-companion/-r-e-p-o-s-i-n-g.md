//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[Companion](index.md)/[REPOSING](-r-e-p-o-s-i-n-g.md)

# REPOSING

[androidJvm]\
const val [REPOSING](-r-e-p-o-s-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
