//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGoToLocationStatusChangedListener](../index.md)/[Companion](index.md)/[GOING](-g-o-i-n-g.md)

# GOING

[androidJvm]\
const val [GOING](-g-o-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
