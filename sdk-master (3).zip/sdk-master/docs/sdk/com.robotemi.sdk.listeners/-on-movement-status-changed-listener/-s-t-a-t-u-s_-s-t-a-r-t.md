[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnMovementStatusChangedListener](index.md) / [STATUS_START](./-s-t-a-t-u-s_-s-t-a-r-t.md)

# STATUS_START

`const val STATUS_START: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)