//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnMovementStatusChangedListener](index.md)/[onMovementStatusChanged](on-movement-status-changed.md)

# onMovementStatusChanged

[androidJvm]\
abstract fun [onMovementStatusChanged](on-movement-status-changed.md)(type: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), status: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))
