[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnMovementStatusChangedListener](index.md) / [STATUS_OBSTACLE_DETECTED](./-s-t-a-t-u-s_-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md)

# STATUS_OBSTACLE_DETECTED

`const val STATUS_OBSTACLE_DETECTED: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)