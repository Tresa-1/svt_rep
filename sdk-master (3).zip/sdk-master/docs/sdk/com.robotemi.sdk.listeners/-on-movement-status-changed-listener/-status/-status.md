//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Status](index.md)/[Status](-status.md)

# Status

[androidJvm]\
fun [Status](-status.md)()
