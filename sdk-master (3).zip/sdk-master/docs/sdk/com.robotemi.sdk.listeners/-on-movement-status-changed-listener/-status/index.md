//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Status](index.md)

# Status

[androidJvm]\
annotation class [Status](index.md)

## Constructors

| | |
|---|---|
| [Status](-status.md) | [androidJvm]<br>fun [Status](-status.md)() |
