[sdk](../../../index.md) / [com.robotemi.sdk.listeners](../../index.md) / [OnMovementStatusChangedListener](../index.md) / [Status](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Status()`