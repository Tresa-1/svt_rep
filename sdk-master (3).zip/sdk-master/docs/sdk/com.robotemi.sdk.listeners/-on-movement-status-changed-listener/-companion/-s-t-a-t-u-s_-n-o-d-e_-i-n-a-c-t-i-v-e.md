//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)/[STATUS_NODE_INACTIVE](-s-t-a-t-u-s_-n-o-d-e_-i-n-a-c-t-i-v-e.md)

# STATUS_NODE_INACTIVE

[androidJvm]\
const val [STATUS_NODE_INACTIVE](-s-t-a-t-u-s_-n-o-d-e_-i-n-a-c-t-i-v-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
