//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [STATUS_ABORT](-s-t-a-t-u-s_-a-b-o-r-t.md) | [androidJvm]<br>const val [STATUS_ABORT](-s-t-a-t-u-s_-a-b-o-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [STATUS_CALCULATING](-s-t-a-t-u-s_-c-a-l-c-u-l-a-t-i-n-g.md) | [androidJvm]<br>const val [STATUS_CALCULATING](-s-t-a-t-u-s_-c-a-l-c-u-l-a-t-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [STATUS_COMPLETE](-s-t-a-t-u-s_-c-o-m-p-l-e-t-e.md) | [androidJvm]<br>const val [STATUS_COMPLETE](-s-t-a-t-u-s_-c-o-m-p-l-e-t-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [STATUS_GOING](-s-t-a-t-u-s_-g-o-i-n-g.md) | [androidJvm]<br>const val [STATUS_GOING](-s-t-a-t-u-s_-g-o-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [STATUS_NODE_INACTIVE](-s-t-a-t-u-s_-n-o-d-e_-i-n-a-c-t-i-v-e.md) | [androidJvm]<br>const val [STATUS_NODE_INACTIVE](-s-t-a-t-u-s_-n-o-d-e_-i-n-a-c-t-i-v-e.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [STATUS_OBSTACLE_DETECTED](-s-t-a-t-u-s_-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md) | [androidJvm]<br>const val [STATUS_OBSTACLE_DETECTED](-s-t-a-t-u-s_-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [STATUS_START](-s-t-a-t-u-s_-s-t-a-r-t.md) | [androidJvm]<br>const val [STATUS_START](-s-t-a-t-u-s_-s-t-a-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [TYPE_SKID_JOY](-t-y-p-e_-s-k-i-d_-j-o-y.md) | [androidJvm]<br>const val [TYPE_SKID_JOY](-t-y-p-e_-s-k-i-d_-j-o-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [TYPE_TURN_BY](-t-y-p-e_-t-u-r-n_-b-y.md) | [androidJvm]<br>const val [TYPE_TURN_BY](-t-y-p-e_-t-u-r-n_-b-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
