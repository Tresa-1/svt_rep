//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)/[STATUS_ABORT](-s-t-a-t-u-s_-a-b-o-r-t.md)

# STATUS_ABORT

[androidJvm]\
const val [STATUS_ABORT](-s-t-a-t-u-s_-a-b-o-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
