//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)/[TYPE_SKID_JOY](-t-y-p-e_-s-k-i-d_-j-o-y.md)

# TYPE_SKID_JOY

[androidJvm]\
const val [TYPE_SKID_JOY](-t-y-p-e_-s-k-i-d_-j-o-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
