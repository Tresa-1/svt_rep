//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)/[STATUS_CALCULATING](-s-t-a-t-u-s_-c-a-l-c-u-l-a-t-i-n-g.md)

# STATUS_CALCULATING

[androidJvm]\
const val [STATUS_CALCULATING](-s-t-a-t-u-s_-c-a-l-c-u-l-a-t-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
