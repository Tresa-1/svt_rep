//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)/[STATUS_GOING](-s-t-a-t-u-s_-g-o-i-n-g.md)

# STATUS_GOING

[androidJvm]\
const val [STATUS_GOING](-s-t-a-t-u-s_-g-o-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
