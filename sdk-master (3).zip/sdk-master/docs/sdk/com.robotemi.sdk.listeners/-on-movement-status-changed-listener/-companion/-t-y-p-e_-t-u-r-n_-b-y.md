//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Companion](index.md)/[TYPE_TURN_BY](-t-y-p-e_-t-u-r-n_-b-y.md)

# TYPE_TURN_BY

[androidJvm]\
const val [TYPE_TURN_BY](-t-y-p-e_-t-u-r-n_-b-y.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
