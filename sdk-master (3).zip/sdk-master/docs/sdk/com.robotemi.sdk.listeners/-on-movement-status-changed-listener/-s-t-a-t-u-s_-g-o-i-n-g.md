[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnMovementStatusChangedListener](index.md) / [STATUS_GOING](./-s-t-a-t-u-s_-g-o-i-n-g.md)

# STATUS_GOING

`const val STATUS_GOING: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)