//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Type](index.md)/[Type](-type.md)

# Type

[androidJvm]\
fun [Type](-type.md)()
