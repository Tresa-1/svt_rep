//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnMovementStatusChangedListener](../index.md)/[Type](index.md)

# Type

[androidJvm]\
annotation class [Type](index.md)

## Constructors

| | |
|---|---|
| [Type](-type.md) | [androidJvm]<br>fun [Type](-type.md)() |
