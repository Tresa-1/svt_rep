//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnMovementStatusChangedListener](index.md)

# OnMovementStatusChangedListener

[androidJvm]\
interface [OnMovementStatusChangedListener](index.md)

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |
| [Status](-status/index.md) | [androidJvm]<br>annotation class [Status](-status/index.md) |
| [Type](-type/index.md) | [androidJvm]<br>annotation class [Type](-type/index.md) |

## Functions

| Name | Summary |
|---|---|
| [onMovementStatusChanged](on-movement-status-changed.md) | [androidJvm]<br>abstract fun [onMovementStatusChanged](on-movement-status-changed.md)(type: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html), status: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)) |
