[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnMovementStatusChangedListener](index.md) / [TYPE_SKID_JOY](./-t-y-p-e_-s-k-i-d_-j-o-y.md)

# TYPE_SKID_JOY

`const val TYPE_SKID_JOY: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)