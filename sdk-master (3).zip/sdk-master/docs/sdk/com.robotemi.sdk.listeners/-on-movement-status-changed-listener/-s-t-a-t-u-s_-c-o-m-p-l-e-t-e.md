[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnMovementStatusChangedListener](index.md) / [STATUS_COMPLETE](./-s-t-a-t-u-s_-c-o-m-p-l-e-t-e.md)

# STATUS_COMPLETE

`const val STATUS_COMPLETE: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)