[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnMovementStatusChangedListener](index.md) / [STATUS_ABORT](./-s-t-a-t-u-s_-a-b-o-r-t.md)

# STATUS_ABORT

`const val STATUS_ABORT: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)