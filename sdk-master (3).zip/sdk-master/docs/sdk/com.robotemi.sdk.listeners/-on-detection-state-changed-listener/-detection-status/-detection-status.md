//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDetectionStateChangedListener](../index.md)/[DetectionStatus](index.md)/[DetectionStatus](-detection-status.md)

# DetectionStatus

[androidJvm]\
fun [DetectionStatus](-detection-status.md)()
