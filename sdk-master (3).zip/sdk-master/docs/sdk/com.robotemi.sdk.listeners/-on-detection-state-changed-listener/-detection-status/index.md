//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDetectionStateChangedListener](../index.md)/[DetectionStatus](index.md)

# DetectionStatus

[androidJvm]\
annotation class [DetectionStatus](index.md)

## Constructors

| | |
|---|---|
| [DetectionStatus](-detection-status.md) | [androidJvm]<br>fun [DetectionStatus](-detection-status.md)() |
