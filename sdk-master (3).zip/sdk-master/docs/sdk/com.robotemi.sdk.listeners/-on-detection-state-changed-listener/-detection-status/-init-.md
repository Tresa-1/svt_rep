[sdk](../../../index.md) / [com.robotemi.sdk.listeners](../../index.md) / [OnDetectionStateChangedListener](../index.md) / [DetectionStatus](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`DetectionStatus()`