//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDetectionStateChangedListener](../index.md)/[Companion](index.md)/[IDLE](-i-d-l-e.md)

# IDLE

[androidJvm]\
const val [IDLE](-i-d-l-e.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0
