//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDetectionStateChangedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [DETECTED](-d-e-t-e-c-t-e-d.md) | [androidJvm]<br>const val [DETECTED](-d-e-t-e-c-t-e-d.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2 |
| [IDLE](-i-d-l-e.md) | [androidJvm]<br>const val [IDLE](-i-d-l-e.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0 |
| [LOST](-l-o-s-t.md) | [androidJvm]<br>const val [LOST](-l-o-s-t.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1 |
