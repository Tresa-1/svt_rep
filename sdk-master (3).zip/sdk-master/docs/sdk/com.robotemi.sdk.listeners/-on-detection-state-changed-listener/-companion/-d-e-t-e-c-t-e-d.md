//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDetectionStateChangedListener](../index.md)/[Companion](index.md)/[DETECTED](-d-e-t-e-c-t-e-d.md)

# DETECTED

[androidJvm]\
const val [DETECTED](-d-e-t-e-c-t-e-d.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2
