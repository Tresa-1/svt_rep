//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDetectionStateChangedListener](../index.md)/[Companion](index.md)/[LOST](-l-o-s-t.md)

# LOST

[androidJvm]\
const val [LOST](-l-o-s-t.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1
