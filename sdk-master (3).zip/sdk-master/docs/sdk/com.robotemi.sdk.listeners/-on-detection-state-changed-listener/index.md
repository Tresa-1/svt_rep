//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnDetectionStateChangedListener](index.md)

# OnDetectionStateChangedListener

[androidJvm]\
interface [OnDetectionStateChangedListener](index.md)

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |
| [DetectionStatus](-detection-status/index.md) | [androidJvm]<br>annotation class [DetectionStatus](-detection-status/index.md) |

## Functions

| Name | Summary |
|---|---|
| [onDetectionStateChanged](on-detection-state-changed.md) | [androidJvm]<br>abstract fun [onDetectionStateChanged](on-detection-state-changed.md)(state: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))<br>Available status: |
