//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnDetectionStateChangedListener](index.md)/[onDetectionStateChanged](on-detection-state-changed.md)

# onDetectionStateChanged

[androidJvm]\
abstract fun [onDetectionStateChanged](on-detection-state-changed.md)(state: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))

Available status:

- 
   [OnDetectionStateChangedListener.IDLE](-companion/-i-d-l-e.md)
- 
   [OnDetectionStateChangedListener.LOST](-companion/-l-o-s-t.md)
- 
   [OnDetectionStateChangedListener.DETECTED](-companion/-d-e-t-e-c-t-e-d.md)

## Parameters

androidJvm

| | |
|---|---|
| state | Current state. |
