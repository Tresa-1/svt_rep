[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnDetectionStateChangedListener](index.md) / [LOST](./-l-o-s-t.md)

# LOST

`const val LOST: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)