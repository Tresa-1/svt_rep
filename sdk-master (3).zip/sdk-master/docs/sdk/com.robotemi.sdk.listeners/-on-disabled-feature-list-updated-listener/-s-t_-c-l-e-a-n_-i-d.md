[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnDisabledFeatureListUpdatedListener](index.md) / [ST_CLEAN_ID](./-s-t_-c-l-e-a-n_-i-d.md)

# ST_CLEAN_ID

`const val ST_CLEAN_ID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)