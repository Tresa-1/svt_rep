//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnDisabledFeatureListUpdatedListener](index.md)/[onDisabledFeatureListUpdated](on-disabled-feature-list-updated.md)

# onDisabledFeatureListUpdated

[androidJvm]\
abstract fun [onDisabledFeatureListUpdated](on-disabled-feature-list-updated.md)(disabledFeatureList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;)
