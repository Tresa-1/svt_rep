//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [BE_WITH_ID](-b-e_-w-i-t-h_-i-d.md) | [androidJvm]<br>const val [BE_WITH_ID](-b-e_-w-i-t-h_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [GO_TO_ID](-g-o_-t-o_-i-d.md) | [androidJvm]<br>const val [GO_TO_ID](-g-o_-t-o_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [HARD_BUTTON_ID](-h-a-r-d_-b-u-t-t-o-n_-i-d.md) | [androidJvm]<br>const val [HARD_BUTTON_ID](-h-a-r-d_-b-u-t-t-o-n_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [MIC_ID](-m-i-c_-i-d.md) | [androidJvm]<br>const val [MIC_ID](-m-i-c_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [MQTT_ID](-m-q-t-t_-i-d.md) | [androidJvm]<br>const val [MQTT_ID](-m-q-t-t_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [SPEAKER_ID](-s-p-e-a-k-e-r_-i-d.md) | [androidJvm]<br>const val [SPEAKER_ID](-s-p-e-a-k-e-r_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ST_CLEAN_ID](-s-t_-c-l-e-a-n_-i-d.md) | [androidJvm]<br>const val [ST_CLEAN_ID](-s-t_-c-l-e-a-n_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ST_VALID_ID](-s-t_-v-a-l-i-d_-i-d.md) | [androidJvm]<br>const val [ST_VALID_ID](-s-t_-v-a-l-i-d_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [WAKEUP_ID](-w-a-k-e-u-p_-i-d.md) | [androidJvm]<br>const val [WAKEUP_ID](-w-a-k-e-u-p_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
