//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[GO_TO_ID](-g-o_-t-o_-i-d.md)

# GO_TO_ID

[androidJvm]\
const val [GO_TO_ID](-g-o_-t-o_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
