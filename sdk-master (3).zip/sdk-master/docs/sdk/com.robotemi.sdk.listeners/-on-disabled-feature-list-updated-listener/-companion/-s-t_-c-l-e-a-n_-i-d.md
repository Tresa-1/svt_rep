//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[ST_CLEAN_ID](-s-t_-c-l-e-a-n_-i-d.md)

# ST_CLEAN_ID

[androidJvm]\
const val [ST_CLEAN_ID](-s-t_-c-l-e-a-n_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
