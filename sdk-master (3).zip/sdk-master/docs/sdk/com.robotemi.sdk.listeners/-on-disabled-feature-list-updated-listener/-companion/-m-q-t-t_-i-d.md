//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[MQTT_ID](-m-q-t-t_-i-d.md)

# MQTT_ID

[androidJvm]\
const val [MQTT_ID](-m-q-t-t_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
