//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[ST_VALID_ID](-s-t_-v-a-l-i-d_-i-d.md)

# ST_VALID_ID

[androidJvm]\
const val [ST_VALID_ID](-s-t_-v-a-l-i-d_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
