//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[MIC_ID](-m-i-c_-i-d.md)

# MIC_ID

[androidJvm]\
const val [MIC_ID](-m-i-c_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
