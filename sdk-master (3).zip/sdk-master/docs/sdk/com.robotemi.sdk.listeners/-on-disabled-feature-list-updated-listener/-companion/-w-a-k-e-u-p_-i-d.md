//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[WAKEUP_ID](-w-a-k-e-u-p_-i-d.md)

# WAKEUP_ID

[androidJvm]\
const val [WAKEUP_ID](-w-a-k-e-u-p_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
