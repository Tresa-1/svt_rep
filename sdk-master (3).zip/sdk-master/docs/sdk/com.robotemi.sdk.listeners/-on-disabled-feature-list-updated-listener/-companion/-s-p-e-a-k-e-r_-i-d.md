//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[SPEAKER_ID](-s-p-e-a-k-e-r_-i-d.md)

# SPEAKER_ID

[androidJvm]\
const val [SPEAKER_ID](-s-p-e-a-k-e-r_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
