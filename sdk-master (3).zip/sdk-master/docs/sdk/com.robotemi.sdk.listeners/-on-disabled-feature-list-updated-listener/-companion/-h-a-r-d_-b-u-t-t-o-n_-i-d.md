//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnDisabledFeatureListUpdatedListener](../index.md)/[Companion](index.md)/[HARD_BUTTON_ID](-h-a-r-d_-b-u-t-t-o-n_-i-d.md)

# HARD_BUTTON_ID

[androidJvm]\
const val [HARD_BUTTON_ID](-h-a-r-d_-b-u-t-t-o-n_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
