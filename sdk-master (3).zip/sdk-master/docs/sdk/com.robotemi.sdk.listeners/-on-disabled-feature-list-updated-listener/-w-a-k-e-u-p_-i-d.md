[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnDisabledFeatureListUpdatedListener](index.md) / [WAKEUP_ID](./-w-a-k-e-u-p_-i-d.md)

# WAKEUP_ID

`const val WAKEUP_ID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)