[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnDisabledFeatureListUpdatedListener](index.md) / [MQTT_ID](./-m-q-t-t_-i-d.md)

# MQTT_ID

`const val MQTT_ID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)