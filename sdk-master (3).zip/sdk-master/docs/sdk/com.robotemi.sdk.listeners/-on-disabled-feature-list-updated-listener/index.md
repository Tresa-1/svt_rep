//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnDisabledFeatureListUpdatedListener](index.md)

# OnDisabledFeatureListUpdatedListener

[androidJvm]\
interface [OnDisabledFeatureListUpdatedListener](index.md)

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |

## Functions

| Name | Summary |
|---|---|
| [onDisabledFeatureListUpdated](on-disabled-feature-list-updated.md) | [androidJvm]<br>abstract fun [onDisabledFeatureListUpdated](on-disabled-feature-list-updated.md)(disabledFeatureList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;) |
