[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnDisabledFeatureListUpdatedListener](index.md) / [BE_WITH_ID](./-b-e_-w-i-t-h_-i-d.md)

# BE_WITH_ID

`const val BE_WITH_ID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)