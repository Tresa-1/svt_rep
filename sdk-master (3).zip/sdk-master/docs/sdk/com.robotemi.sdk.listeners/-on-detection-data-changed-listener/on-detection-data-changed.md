//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnDetectionDataChangedListener](index.md)/[onDetectionDataChanged](on-detection-data-changed.md)

# onDetectionDataChanged

[androidJvm]\
abstract fun [onDetectionDataChanged](on-detection-data-changed.md)(detectionData: [DetectionData](../../com.robotemi.sdk.model/-detection-data/index.md))
