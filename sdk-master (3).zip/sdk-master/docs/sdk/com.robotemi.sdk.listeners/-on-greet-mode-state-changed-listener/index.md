//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnGreetModeStateChangedListener](index.md)

# OnGreetModeStateChangedListener

[androidJvm]\
interface [OnGreetModeStateChangedListener](index.md)

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |
| [State](-state/index.md) | [androidJvm]<br>annotation class [State](-state/index.md) |

## Functions

| Name | Summary |
|---|---|
| [onGreetModeStateChanged](on-greet-mode-state-changed.md) | [androidJvm]<br>abstract fun [onGreetModeStateChanged](on-greet-mode-state-changed.md)(state: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)) |
