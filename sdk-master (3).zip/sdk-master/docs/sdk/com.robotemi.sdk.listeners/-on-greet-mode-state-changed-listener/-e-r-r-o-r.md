[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGreetModeStateChangedListener](index.md) / [ERROR](./-e-r-r-o-r.md)

# ERROR

`const val ERROR: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)