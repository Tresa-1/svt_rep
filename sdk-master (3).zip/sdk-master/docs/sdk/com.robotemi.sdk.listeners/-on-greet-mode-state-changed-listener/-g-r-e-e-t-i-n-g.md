[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGreetModeStateChangedListener](index.md) / [GREETING](./-g-r-e-e-t-i-n-g.md)

# GREETING

`const val GREETING: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)