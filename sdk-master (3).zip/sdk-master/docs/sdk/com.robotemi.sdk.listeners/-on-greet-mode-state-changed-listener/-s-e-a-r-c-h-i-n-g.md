[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGreetModeStateChangedListener](index.md) / [SEARCHING](./-s-e-a-r-c-h-i-n-g.md)

# SEARCHING

`const val SEARCHING: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)