//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[Companion](index.md)/[GREETING](-g-r-e-e-t-i-n-g.md)

# GREETING

[androidJvm]\
const val [GREETING](-g-r-e-e-t-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 3
