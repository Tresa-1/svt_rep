//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[Companion](index.md)/[INTERACTION](-i-n-t-e-r-a-c-t-i-o-n.md)

# INTERACTION

[androidJvm]\
const val [INTERACTION](-i-n-t-e-r-a-c-t-i-o-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 4
