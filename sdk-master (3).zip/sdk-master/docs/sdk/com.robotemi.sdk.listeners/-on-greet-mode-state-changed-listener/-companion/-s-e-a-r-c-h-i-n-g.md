//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[Companion](index.md)/[SEARCHING](-s-e-a-r-c-h-i-n-g.md)

# SEARCHING

[androidJvm]\
const val [SEARCHING](-s-e-a-r-c-h-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1
