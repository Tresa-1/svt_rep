//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[Companion](index.md)/[PREPARING](-p-r-e-p-a-r-i-n-g.md)

# PREPARING

[androidJvm]\
const val [PREPARING](-p-r-e-p-a-r-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2
