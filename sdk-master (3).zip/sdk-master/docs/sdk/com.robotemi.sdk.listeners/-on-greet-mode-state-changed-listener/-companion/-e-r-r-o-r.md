//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[Companion](index.md)/[ERROR](-e-r-r-o-r.md)

# ERROR

[androidJvm]\
const val [ERROR](-e-r-r-o-r.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)
