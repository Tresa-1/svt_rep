//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [ERROR](-e-r-r-o-r.md) | [androidJvm]<br>const val [ERROR](-e-r-r-o-r.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [GREETING](-g-r-e-e-t-i-n-g.md) | [androidJvm]<br>const val [GREETING](-g-r-e-e-t-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 3 |
| [HOLD](-h-o-l-d.md) | [androidJvm]<br>const val [HOLD](-h-o-l-d.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0 |
| [INTERACTION](-i-n-t-e-r-a-c-t-i-o-n.md) | [androidJvm]<br>const val [INTERACTION](-i-n-t-e-r-a-c-t-i-o-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 4 |
| [POST_INTERACTION](-p-o-s-t_-i-n-t-e-r-a-c-t-i-o-n.md) | [androidJvm]<br>const val [POST_INTERACTION](-p-o-s-t_-i-n-t-e-r-a-c-t-i-o-n.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 5 |
| [PREPARING](-p-r-e-p-a-r-i-n-g.md) | [androidJvm]<br>const val [PREPARING](-p-r-e-p-a-r-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2 |
| [SEARCHING](-s-e-a-r-c-h-i-n-g.md) | [androidJvm]<br>const val [SEARCHING](-s-e-a-r-c-h-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1 |
