//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[State](index.md)/[State](-state.md)

# State

[androidJvm]\
fun [State](-state.md)()
