//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnGreetModeStateChangedListener](../index.md)/[State](index.md)

# State

[androidJvm]\
annotation class [State](index.md)

## Constructors

| | |
|---|---|
| [State](-state.md) | [androidJvm]<br>fun [State](-state.md)() |
