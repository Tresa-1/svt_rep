[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGreetModeStateChangedListener](index.md) / [INTERACTION](./-i-n-t-e-r-a-c-t-i-o-n.md)

# INTERACTION

`const val INTERACTION: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)