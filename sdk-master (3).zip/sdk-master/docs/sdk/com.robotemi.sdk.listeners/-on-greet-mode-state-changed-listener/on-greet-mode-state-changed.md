//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnGreetModeStateChangedListener](index.md)/[onGreetModeStateChanged](on-greet-mode-state-changed.md)

# onGreetModeStateChanged

[androidJvm]\
abstract fun [onGreetModeStateChanged](on-greet-mode-state-changed.md)(state: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
