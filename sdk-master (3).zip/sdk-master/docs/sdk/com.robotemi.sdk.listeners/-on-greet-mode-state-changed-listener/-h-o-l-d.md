[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGreetModeStateChangedListener](index.md) / [HOLD](./-h-o-l-d.md)

# HOLD

`const val HOLD: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)