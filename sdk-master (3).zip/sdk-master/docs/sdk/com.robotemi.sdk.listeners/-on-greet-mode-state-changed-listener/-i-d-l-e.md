[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnGreetModeStateChangedListener](index.md) / [IDLE](./-i-d-l-e.md)

# IDLE

`const val IDLE: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)