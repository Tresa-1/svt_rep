//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnBeWithMeStatusChangedListener](../index.md)/[BeWithMeStatus](index.md)

# BeWithMeStatus

[androidJvm]\
annotation class [BeWithMeStatus](index.md)

## Constructors

| | |
|---|---|
| [BeWithMeStatus](-be-with-me-status.md) | [androidJvm]<br>fun [BeWithMeStatus](-be-with-me-status.md)() |
