[sdk](../../../index.md) / [com.robotemi.sdk.listeners](../../index.md) / [OnBeWithMeStatusChangedListener](../index.md) / [BeWithMeStatus](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`BeWithMeStatus()`