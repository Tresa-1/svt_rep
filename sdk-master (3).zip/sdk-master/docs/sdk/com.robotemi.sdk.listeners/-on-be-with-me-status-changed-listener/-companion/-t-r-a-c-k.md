//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnBeWithMeStatusChangedListener](../index.md)/[Companion](index.md)/[TRACK](-t-r-a-c-k.md)

# TRACK

[androidJvm]\
const val [TRACK](-t-r-a-c-k.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
