//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnBeWithMeStatusChangedListener](../index.md)/[Companion](index.md)/[OBSTACLE_DETECTED](-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md)

# OBSTACLE_DETECTED

[androidJvm]\
const val [OBSTACLE_DETECTED](-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
