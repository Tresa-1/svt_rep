//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnBeWithMeStatusChangedListener](../index.md)/[Companion](index.md)/[START](-s-t-a-r-t.md)

# START

[androidJvm]\
const val [START](-s-t-a-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
