//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnBeWithMeStatusChangedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [ABORT](-a-b-o-r-t.md) | [androidJvm]<br>const val [ABORT](-a-b-o-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [CALCULATING](-c-a-l-c-u-l-a-t-i-n-g.md) | [androidJvm]<br>const val [CALCULATING](-c-a-l-c-u-l-a-t-i-n-g.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [OBSTACLE_DETECTED](-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md) | [androidJvm]<br>const val [OBSTACLE_DETECTED](-o-b-s-t-a-c-l-e_-d-e-t-e-c-t-e-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [SEARCH](-s-e-a-r-c-h.md) | [androidJvm]<br>const val [SEARCH](-s-e-a-r-c-h.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [START](-s-t-a-r-t.md) | [androidJvm]<br>const val [START](-s-t-a-r-t.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [TRACK](-t-r-a-c-k.md) | [androidJvm]<br>const val [TRACK](-t-r-a-c-k.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
