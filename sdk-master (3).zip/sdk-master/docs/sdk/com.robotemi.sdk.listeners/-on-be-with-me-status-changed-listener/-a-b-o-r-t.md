[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnBeWithMeStatusChangedListener](index.md) / [ABORT](./-a-b-o-r-t.md)

# ABORT

`const val ABORT: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)