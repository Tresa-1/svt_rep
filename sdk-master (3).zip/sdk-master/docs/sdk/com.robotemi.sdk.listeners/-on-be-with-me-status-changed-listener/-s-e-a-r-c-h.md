[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnBeWithMeStatusChangedListener](index.md) / [SEARCH](./-s-e-a-r-c-h.md)

# SEARCH

`const val SEARCH: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)