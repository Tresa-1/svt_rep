//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnLocationsUpdatedListener](index.md)

# OnLocationsUpdatedListener

[androidJvm]\
interface [OnLocationsUpdatedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onLocationsUpdated](on-locations-updated.md) | [androidJvm]<br>abstract fun [onLocationsUpdated](on-locations-updated.md)(locations: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)&gt;)<br>Called when locations were changed. |
