//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTtsVisualizerFftDataChangedListener](index.md)

# OnTtsVisualizerFftDataChangedListener

[androidJvm]\
interface [OnTtsVisualizerFftDataChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onTtsVisualizerFftDataChanged](on-tts-visualizer-fft-data-changed.md) | [androidJvm]<br>abstract fun [onTtsVisualizerFftDataChanged](on-tts-visualizer-fft-data-changed.md)(fft: [ByteArray](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-byte-array/index.html)) |
