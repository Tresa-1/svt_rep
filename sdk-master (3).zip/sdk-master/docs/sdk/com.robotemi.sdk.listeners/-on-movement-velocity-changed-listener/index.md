//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnMovementVelocityChangedListener](index.md)

# OnMovementVelocityChangedListener

[androidJvm]\
interface [OnMovementVelocityChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onMovementVelocityChanged](on-movement-velocity-changed.md) | [androidJvm]<br>abstract fun [onMovementVelocityChanged](on-movement-velocity-changed.md)(velocity: [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html)) |
