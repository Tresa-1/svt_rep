//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnMovementVelocityChangedListener](index.md)/[onMovementVelocityChanged](on-movement-velocity-changed.md)

# onMovementVelocityChanged

[androidJvm]\
abstract fun [onMovementVelocityChanged](on-movement-velocity-changed.md)(velocity: [Float](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-float/index.html))
