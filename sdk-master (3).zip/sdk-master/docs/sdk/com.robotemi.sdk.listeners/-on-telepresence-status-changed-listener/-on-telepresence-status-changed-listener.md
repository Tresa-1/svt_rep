//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTelepresenceStatusChangedListener](index.md)/[OnTelepresenceStatusChangedListener](-on-telepresence-status-changed-listener.md)

# OnTelepresenceStatusChangedListener

[androidJvm]\
fun [OnTelepresenceStatusChangedListener](-on-telepresence-status-changed-listener.md)(sessionId: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))
