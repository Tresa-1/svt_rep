//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTelepresenceStatusChangedListener](index.md)/[onTelepresenceStatusChanged](on-telepresence-status-changed.md)

# onTelepresenceStatusChanged

[androidJvm]\
abstract fun [onTelepresenceStatusChanged](on-telepresence-status-changed.md)(callState: [CallState](../../com.robotemi.sdk.telepresence/-call-state/index.md))

Called when Telepresence status was changed.
