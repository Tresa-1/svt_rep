//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnTelepresenceStatusChangedListener](index.md)/[sessionId](session-id.md)

# sessionId

[androidJvm]\
var [sessionId](session-id.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
