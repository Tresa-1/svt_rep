[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnTelepresenceStatusChangedListener](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`OnTelepresenceStatusChangedListener(sessionId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`