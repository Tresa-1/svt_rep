//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnRobotReadyListener](index.md)

# OnRobotReadyListener

[androidJvm]\
interface [OnRobotReadyListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onRobotReady](on-robot-ready.md) | [androidJvm]<br>abstract fun [onRobotReady](on-robot-ready.md)(isReady: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))<br>Called when connection with robot was established. |
