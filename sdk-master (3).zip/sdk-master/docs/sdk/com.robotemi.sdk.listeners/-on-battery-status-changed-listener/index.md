//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnBatteryStatusChangedListener](index.md)

# OnBatteryStatusChangedListener

[androidJvm]\
interface [OnBatteryStatusChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onBatteryStatusChanged](on-battery-status-changed.md) | [androidJvm]<br>abstract fun [onBatteryStatusChanged](on-battery-status-changed.md)(batteryData: [BatteryData](../../com.robotemi.sdk/-battery-data/index.md)?)<br>Called when there's an update to temi's battery data |
