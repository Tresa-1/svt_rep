//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnBatteryStatusChangedListener](index.md)/[onBatteryStatusChanged](on-battery-status-changed.md)

# onBatteryStatusChanged

[androidJvm]\
abstract fun [onBatteryStatusChanged](on-battery-status-changed.md)(batteryData: [BatteryData](../../com.robotemi.sdk/-battery-data/index.md)?)

Called when there's an update to temi's battery data
