//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnUserInteractionChangedListener](index.md)

# OnUserInteractionChangedListener

[androidJvm]\
interface [OnUserInteractionChangedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onUserInteraction](on-user-interaction.md) | [androidJvm]<br>abstract fun [onUserInteraction](on-user-interaction.md)(isInteracting: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))<br>Listen for user interaction with temi. |
