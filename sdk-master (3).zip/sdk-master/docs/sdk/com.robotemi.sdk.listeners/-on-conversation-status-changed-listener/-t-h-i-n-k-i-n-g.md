[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnConversationStatusChangedListener](index.md) / [THINKING](./-t-h-i-n-k-i-n-g.md)

# THINKING

`const val THINKING: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)