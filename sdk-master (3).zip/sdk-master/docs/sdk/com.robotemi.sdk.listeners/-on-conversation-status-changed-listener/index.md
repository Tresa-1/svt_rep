//[sdk](../../../index.md)/[com.robotemi.sdk.listeners](../index.md)/[OnConversationStatusChangedListener](index.md)

# OnConversationStatusChangedListener

[androidJvm]\
interface [OnConversationStatusChangedListener](index.md)

## Types

| Name | Summary |
|---|---|
| [Companion](-companion/index.md) | [androidJvm]<br>object [Companion](-companion/index.md) |
| [Status](-status/index.md) | [androidJvm]<br>annotation class [Status](-status/index.md) |

## Functions

| Name | Summary |
|---|---|
| [onConversationStatusChanged](on-conversation-status-changed.md) | [androidJvm]<br>abstract fun [onConversationStatusChanged](on-conversation-status-changed.md)(status: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), text: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)) |
