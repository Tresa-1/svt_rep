//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnConversationStatusChangedListener](../index.md)/[Companion](index.md)/[SPEAKING](-s-p-e-a-k-i-n-g.md)

# SPEAKING

[androidJvm]\
const val [SPEAKING](-s-p-e-a-k-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 3
