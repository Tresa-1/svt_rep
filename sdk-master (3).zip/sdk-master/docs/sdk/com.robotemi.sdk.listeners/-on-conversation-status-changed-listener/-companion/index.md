//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnConversationStatusChangedListener](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [IDLE](-i-d-l-e.md) | [androidJvm]<br>const val [IDLE](-i-d-l-e.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 0 |
| [LISTENING](-l-i-s-t-e-n-i-n-g.md) | [androidJvm]<br>const val [LISTENING](-l-i-s-t-e-n-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 1 |
| [SPEAKING](-s-p-e-a-k-i-n-g.md) | [androidJvm]<br>const val [SPEAKING](-s-p-e-a-k-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 3 |
| [THINKING](-t-h-i-n-k-i-n-g.md) | [androidJvm]<br>const val [THINKING](-t-h-i-n-k-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2 |
