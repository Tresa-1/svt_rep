//[sdk](../../../../index.md)/[com.robotemi.sdk.listeners](../../index.md)/[OnConversationStatusChangedListener](../index.md)/[Companion](index.md)/[THINKING](-t-h-i-n-k-i-n-g.md)

# THINKING

[androidJvm]\
const val [THINKING](-t-h-i-n-k-i-n-g.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 2
