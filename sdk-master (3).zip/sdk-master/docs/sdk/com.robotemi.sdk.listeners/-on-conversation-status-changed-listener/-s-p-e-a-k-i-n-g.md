[sdk](../../index.md) / [com.robotemi.sdk.listeners](../index.md) / [OnConversationStatusChangedListener](index.md) / [SPEAKING](./-s-p-e-a-k-i-n-g.md)

# SPEAKING

`const val SPEAKING: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)