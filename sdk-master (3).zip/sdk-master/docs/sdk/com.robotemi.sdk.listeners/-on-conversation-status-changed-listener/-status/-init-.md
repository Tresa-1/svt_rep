[sdk](../../../index.md) / [com.robotemi.sdk.listeners](../../index.md) / [OnConversationStatusChangedListener](../index.md) / [Status](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Status()`