[sdk](../../index.md) / [com.robotemi.sdk.exception](../index.md) / [SdkException](index.md) / [launcherError](./launcher-error.md)

# launcherError

`@JvmStatic fun launcherError(msg: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`SdkException`](index.md)