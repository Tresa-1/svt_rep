[sdk](../../index.md) / [com.robotemi.sdk.exception](../index.md) / [SdkException](index.md) / [CODE_ILLEGAL_ARGUMENT](./-c-o-d-e_-i-l-l-e-g-a-l_-a-r-g-u-m-e-n-t.md)

# CODE_ILLEGAL_ARGUMENT

`const val CODE_ILLEGAL_ARGUMENT: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)