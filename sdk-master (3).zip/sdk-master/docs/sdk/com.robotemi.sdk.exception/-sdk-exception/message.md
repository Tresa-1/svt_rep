//[sdk](../../../index.md)/[com.robotemi.sdk.exception](../index.md)/[SdkException](index.md)/[message](message.md)

# message

[androidJvm]\
var [message](message.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
