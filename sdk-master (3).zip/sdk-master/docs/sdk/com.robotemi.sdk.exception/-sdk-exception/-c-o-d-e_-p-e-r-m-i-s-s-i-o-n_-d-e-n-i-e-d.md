[sdk](../../index.md) / [com.robotemi.sdk.exception](../index.md) / [SdkException](index.md) / [CODE_PERMISSION_DENIED](./-c-o-d-e_-p-e-r-m-i-s-s-i-o-n_-d-e-n-i-e-d.md)

# CODE_PERMISSION_DENIED

`const val CODE_PERMISSION_DENIED: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)