//[sdk](../../../index.md)/[com.robotemi.sdk.exception](../index.md)/[SdkException](index.md)/[SdkException](-sdk-exception.md)

# SdkException

[androidJvm]\
fun [SdkException](-sdk-exception.md)(source: Parcel)

fun [SdkException](-sdk-exception.md)(code: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), message: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html))
