[sdk](../../index.md) / [com.robotemi.sdk.exception](../index.md) / [SdkException](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SdkException(source: `[`Parcel`](https://developer.android.com/reference/android/os/Parcel.html)`)`
`SdkException(code: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, message: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`