[sdk](../../index.md) / [com.robotemi.sdk.exception](../index.md) / [SdkException](index.md) / [CODE_LAUNCHER_ERROR](./-c-o-d-e_-l-a-u-n-c-h-e-r_-e-r-r-o-r.md)

# CODE_LAUNCHER_ERROR

`const val CODE_LAUNCHER_ERROR: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)