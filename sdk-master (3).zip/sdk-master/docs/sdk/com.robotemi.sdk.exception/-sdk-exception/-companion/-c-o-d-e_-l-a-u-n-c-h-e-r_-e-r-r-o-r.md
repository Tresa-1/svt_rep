//[sdk](../../../../index.md)/[com.robotemi.sdk.exception](../../index.md)/[SdkException](../index.md)/[Companion](index.md)/[CODE_LAUNCHER_ERROR](-c-o-d-e_-l-a-u-n-c-h-e-r_-e-r-r-o-r.md)

# CODE_LAUNCHER_ERROR

[androidJvm]\
const val [CODE_LAUNCHER_ERROR](-c-o-d-e_-l-a-u-n-c-h-e-r_-e-r-r-o-r.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 500
