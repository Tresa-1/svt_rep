//[sdk](../../../../index.md)/[com.robotemi.sdk.exception](../../index.md)/[SdkException](../index.md)/[Companion](index.md)/[CODE_OPERATION_CONFLICT](-c-o-d-e_-o-p-e-r-a-t-i-o-n_-c-o-n-f-l-i-c-t.md)

# CODE_OPERATION_CONFLICT

[androidJvm]\
const val [CODE_OPERATION_CONFLICT](-c-o-d-e_-o-p-e-r-a-t-i-o-n_-c-o-n-f-l-i-c-t.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 409
