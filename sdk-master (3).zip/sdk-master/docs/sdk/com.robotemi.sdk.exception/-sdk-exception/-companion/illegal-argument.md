//[sdk](../../../../index.md)/[com.robotemi.sdk.exception](../../index.md)/[SdkException](../index.md)/[Companion](index.md)/[illegalArgument](illegal-argument.md)

# illegalArgument

[androidJvm]\

@[JvmStatic](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-static/index.html)

fun [illegalArgument](illegal-argument.md)(msg: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)): [SdkException](../index.md)
