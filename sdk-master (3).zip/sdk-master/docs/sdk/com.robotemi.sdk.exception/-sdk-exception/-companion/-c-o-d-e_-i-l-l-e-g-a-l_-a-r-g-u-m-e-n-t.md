//[sdk](../../../../index.md)/[com.robotemi.sdk.exception](../../index.md)/[SdkException](../index.md)/[Companion](index.md)/[CODE_ILLEGAL_ARGUMENT](-c-o-d-e_-i-l-l-e-g-a-l_-a-r-g-u-m-e-n-t.md)

# CODE_ILLEGAL_ARGUMENT

[androidJvm]\
const val [CODE_ILLEGAL_ARGUMENT](-c-o-d-e_-i-l-l-e-g-a-l_-a-r-g-u-m-e-n-t.md): [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) = 400
