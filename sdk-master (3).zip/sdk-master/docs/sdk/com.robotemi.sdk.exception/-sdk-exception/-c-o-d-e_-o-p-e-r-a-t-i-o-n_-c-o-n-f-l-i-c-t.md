[sdk](../../index.md) / [com.robotemi.sdk.exception](../index.md) / [SdkException](index.md) / [CODE_OPERATION_CONFLICT](./-c-o-d-e_-o-p-e-r-a-t-i-o-n_-c-o-n-f-l-i-c-t.md)

# CODE_OPERATION_CONFLICT

`const val CODE_OPERATION_CONFLICT: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)