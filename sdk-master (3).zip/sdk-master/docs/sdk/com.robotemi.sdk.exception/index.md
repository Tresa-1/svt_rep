//[sdk](../../index.md)/[com.robotemi.sdk.exception](index.md)

# Package com.robotemi.sdk.exception

## Types

| Name | Summary |
|---|---|
| [OnSdkExceptionListener](-on-sdk-exception-listener/index.md) | [androidJvm]<br>interface [OnSdkExceptionListener](-on-sdk-exception-listener/index.md) |
| [SdkException](-sdk-exception/index.md) | [androidJvm]<br>data class [SdkException](-sdk-exception/index.md)(var code: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html), var message: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)) : Parcelable |
