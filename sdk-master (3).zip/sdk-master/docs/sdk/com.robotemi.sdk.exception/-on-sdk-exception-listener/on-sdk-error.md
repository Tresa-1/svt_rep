//[sdk](../../../index.md)/[com.robotemi.sdk.exception](../index.md)/[OnSdkExceptionListener](index.md)/[onSdkError](on-sdk-error.md)

# onSdkError

[androidJvm]\
abstract fun [onSdkError](on-sdk-error.md)(sdkException: [SdkException](../-sdk-exception/index.md))
