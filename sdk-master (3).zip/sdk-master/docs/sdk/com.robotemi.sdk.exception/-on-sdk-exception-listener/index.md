//[sdk](../../../index.md)/[com.robotemi.sdk.exception](../index.md)/[OnSdkExceptionListener](index.md)

# OnSdkExceptionListener

[androidJvm]\
interface [OnSdkExceptionListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onSdkError](on-sdk-error.md) | [androidJvm]<br>abstract fun [onSdkError](on-sdk-error.md)(sdkException: [SdkException](../-sdk-exception/index.md)) |
