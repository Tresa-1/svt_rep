[sdk](../../index.md) / [com.robotemi.sdk.face](../index.md) / [ContactModel](index.md) / [CREATOR](./-c-r-e-a-t-o-r.md)

# CREATOR

`val CREATOR: `[`Creator`](https://developer.android.com/reference/android/os/Parcelable/Creator.html)`<`[`ContactModel`](index.md)`>`