//[sdk](../../../index.md)/[com.robotemi.sdk.face](../index.md)/[ContactModel](index.md)/[lastName](last-name.md)

# lastName

[androidJvm]\
val [lastName](last-name.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
