[sdk](../../index.md) / [com.robotemi.sdk.face](../index.md) / [ContactModel](index.md) / [JSON_KEY_DESCRIPTION](./-j-s-o-n_-k-e-y_-d-e-s-c-r-i-p-t-i-o-n.md)

# JSON_KEY_DESCRIPTION

`const val JSON_KEY_DESCRIPTION: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)