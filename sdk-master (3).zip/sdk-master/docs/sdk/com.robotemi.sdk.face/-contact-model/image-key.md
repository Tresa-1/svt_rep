//[sdk](../../../index.md)/[com.robotemi.sdk.face](../index.md)/[ContactModel](index.md)/[imageKey](image-key.md)

# imageKey

[androidJvm]\
val [imageKey](image-key.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
