//[sdk](../../../../index.md)/[com.robotemi.sdk.face](../../index.md)/[ContactModel](../index.md)/[Companion](index.md)

# Companion

[androidJvm]\
object [Companion](index.md)

## Properties

| Name | Summary |
|---|---|
| [CREATOR](-c-r-e-a-t-o-r.md) | [androidJvm]<br>@[JvmField](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-field/index.html)<br>val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[ContactModel](../index.md)&gt; |
| [JSON_KEY_DESCRIPTION](-j-s-o-n_-k-e-y_-d-e-s-c-r-i-p-t-i-o-n.md) | [androidJvm]<br>const val [JSON_KEY_DESCRIPTION](-j-s-o-n_-k-e-y_-d-e-s-c-r-i-p-t-i-o-n.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [JSON_KEY_USER_ID](-j-s-o-n_-k-e-y_-u-s-e-r_-i-d.md) | [androidJvm]<br>const val [JSON_KEY_USER_ID](-j-s-o-n_-k-e-y_-u-s-e-r_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
