//[sdk](../../../../index.md)/[com.robotemi.sdk.face](../../index.md)/[ContactModel](../index.md)/[Companion](index.md)/[JSON_KEY_USER_ID](-j-s-o-n_-k-e-y_-u-s-e-r_-i-d.md)

# JSON_KEY_USER_ID

[androidJvm]\
const val [JSON_KEY_USER_ID](-j-s-o-n_-k-e-y_-u-s-e-r_-i-d.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
