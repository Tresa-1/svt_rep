//[sdk](../../../index.md)/[com.robotemi.sdk.face](../index.md)/[ContactModel](index.md)/[gender](gender.md)

# gender

[androidJvm]\
val [gender](gender.md): [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)
