//[sdk](../../../index.md)/[com.robotemi.sdk.face](../index.md)/[OnContinuousFaceRecognizedListener](index.md)

# OnContinuousFaceRecognizedListener

[androidJvm]\
interface [OnContinuousFaceRecognizedListener](index.md)

## Functions

| Name | Summary |
|---|---|
| [onContinuousFaceRecognized](on-continuous-face-recognized.md) | [androidJvm]<br>abstract fun [onContinuousFaceRecognized](on-continuous-face-recognized.md)(contactModelList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[ContactModel](../-contact-model/index.md)&gt;) |
