//[sdk](../../../index.md)/[com.robotemi.sdk.face](../index.md)/[OnFaceRecognizedListener](index.md)/[onFaceRecognized](on-face-recognized.md)

# onFaceRecognized

[androidJvm]\
abstract fun [onFaceRecognized](on-face-recognized.md)(contactModelList: [List](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)&lt;[ContactModel](../-contact-model/index.md)&gt;)
