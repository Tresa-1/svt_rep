//[sdk](../../index.md)/[com.robotemi.sdk.face](index.md)

# Package com.robotemi.sdk.face

## Types

| Name | Summary |
|---|---|
| [ContactModel](-contact-model/index.md) | [androidJvm]<br>data class [ContactModel](-contact-model/index.md)@[JvmOverloads](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.jvm/-jvm-overloads/index.html)constructor(val firstName: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, val lastName: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, val gender: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, val imageKey: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, val description: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;, val userId: [String](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) = &quot;&quot;) : Parcelable |
| [OnContinuousFaceRecognizedListener](-on-continuous-face-recognized-listener/index.md) | [androidJvm]<br>interface [OnContinuousFaceRecognizedListener](-on-continuous-face-recognized-listener/index.md) |
| [OnFaceRecognizedListener](-on-face-recognized-listener/index.md) | [androidJvm]<br>interface [OnFaceRecognizedListener](-on-face-recognized-listener/index.md) |
