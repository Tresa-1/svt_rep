//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamUtils](index.md)/[handleActivityStreamObject](handle-activity-stream-object.md)

# handleActivityStreamObject

[androidJvm]\
open fun [handleActivityStreamObject](handle-activity-stream-object.md)(@NonNullactivityStreamObject: [ActivityStreamObject](../-activity-stream-object/index.md))
