//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamPublishMessage](index.md)/[setNumOfUploadedFiles](set-num-of-uploaded-files.md)

# setNumOfUploadedFiles

[androidJvm]\
open fun [setNumOfUploadedFiles](set-num-of-uploaded-files.md)(numOfUploadedFiles: [Int](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html))
