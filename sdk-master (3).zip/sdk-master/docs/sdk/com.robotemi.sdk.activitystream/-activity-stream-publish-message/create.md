//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamPublishMessage](index.md)/[create](create.md)

# create

[androidJvm]\
open fun [create](create.md)(uuid: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)): [ActivityStreamPublishMessage](index.md)
