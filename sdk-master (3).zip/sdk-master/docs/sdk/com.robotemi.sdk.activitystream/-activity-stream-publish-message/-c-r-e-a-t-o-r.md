//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamPublishMessage](index.md)/[CREATOR](-c-r-e-a-t-o-r.md)

# CREATOR

[androidJvm]\
val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[ActivityStreamPublishMessage](index.md)&gt;
