//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamPublishMessage](index.md)/[setSuccess](set-success.md)

# setSuccess

[androidJvm]\
open fun [setSuccess](set-success.md)(success: [Boolean](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html))
