[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamListItem](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ActivityStreamListItem(@NonNull title: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, @NonNull message: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, @NonNull file: `[`File`](https://developer.android.com/reference/java/io/File.html)`, @Nullable url: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?, @Nullable date: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?, @Nullable mimeType: `[`MediaObject.MimeType`](../../com.robotemi.sdk/-media-object/-mime-type/index.md)`?)`