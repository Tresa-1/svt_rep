//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamListItem](../index.md)/[Builder](index.md)/[mediaFile](media-file.md)

# mediaFile

[androidJvm]\
open fun [mediaFile](media-file.md)(@NonNullmediaFile: [File](https://docs.oracle.com/javase/8/docs/api/java/io/File.html)): [ActivityStreamListItem.Builder](index.md)
