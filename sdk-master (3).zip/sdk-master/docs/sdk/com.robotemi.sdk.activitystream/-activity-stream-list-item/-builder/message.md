//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamListItem](../index.md)/[Builder](index.md)/[message](message.md)

# message

[androidJvm]\
open fun [message](message.md)(@NonNullmessage: [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)): [ActivityStreamListItem.Builder](index.md)
