//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[url](url.md)

# url

[androidJvm]\

@Expose

@SerializedName(value = &quot;url&quot;)

@get:Nullable

open val [url](url.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
