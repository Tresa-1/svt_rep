[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamListItem](index.md) / [getLocalPath](./get-local-path.md)

# getLocalPath

`open fun getLocalPath(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!`

Overrides [MediaContainer.getLocalPath](../../com.robotemi.sdk/-media-container/get-local-path.md)

