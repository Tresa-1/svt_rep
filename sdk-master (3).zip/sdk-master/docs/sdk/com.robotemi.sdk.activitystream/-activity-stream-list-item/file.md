//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[file](file.md)

# file

[androidJvm]\

@get:Nullable

open val [file](file.md): [File](https://docs.oracle.com/javase/8/docs/api/java/io/File.html)
