//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[localPath](local-path.md)

# localPath

[androidJvm]\
open val [localPath](local-path.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
