//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[mediaUri](media-uri.md)

# mediaUri

[androidJvm]\

@Expose

@SerializedName(value = &quot;mediaUrl&quot;)

@get:Nullable

open var [mediaUri](media-uri.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
