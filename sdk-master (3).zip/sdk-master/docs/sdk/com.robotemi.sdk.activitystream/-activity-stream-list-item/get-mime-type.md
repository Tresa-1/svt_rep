[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamListItem](index.md) / [getMimeType](./get-mime-type.md)

# getMimeType

`open fun getMimeType(): `[`MediaObject.MimeType`](../../com.robotemi.sdk/-media-object/-mime-type/index.md)`!`

Overrides [MediaContainer.getMimeType](../../com.robotemi.sdk/-media-container/get-mime-type.md)

