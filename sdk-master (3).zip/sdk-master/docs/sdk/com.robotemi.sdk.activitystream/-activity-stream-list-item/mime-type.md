//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamListItem](index.md)/[mimeType](mime-type.md)

# mimeType

[androidJvm]\

@Expose

@SerializedName(value = &quot;mimetype&quot;)

open val [mimeType](mime-type.md): [MediaObject.MimeType](../../com.robotemi.sdk/-media-object/-mime-type/index.md)
