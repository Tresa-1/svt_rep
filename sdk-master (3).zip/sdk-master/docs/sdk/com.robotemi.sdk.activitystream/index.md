//[sdk](../../index.md)/[com.robotemi.sdk.activitystream](index.md)

# Package com.robotemi.sdk.activitystream

## Types

| Name | Summary |
|---|---|
| [ActivityStreamListItem](-activity-stream-list-item/index.md) | [androidJvm]<br>open class [ActivityStreamListItem](-activity-stream-list-item/index.md) : Parcelable, [MediaContainer](../com.robotemi.sdk/-media-container/index.md) |
| [ActivityStreamObject](-activity-stream-object/index.md) | [androidJvm]<br>open class [ActivityStreamObject](-activity-stream-object/index.md) : Parcelable |
| [ActivityStreamPublishMessage](-activity-stream-publish-message/index.md) | [androidJvm]<br>open class [ActivityStreamPublishMessage](-activity-stream-publish-message/index.md) : Parcelable |
| [ActivityStreamUtils](-activity-stream-utils/index.md) | [androidJvm]<br>class [ActivityStreamUtils](-activity-stream-utils/index.md) |
