//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[title](title.md)

# title

[androidJvm]\

@Expose

@SerializedName(value = &quot;title&quot;)

open val [title](title.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
