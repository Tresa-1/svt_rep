[sdk](../../../index.md) / [com.robotemi.sdk.activitystream](../../index.md) / [ActivityStreamObject](../index.md) / [ActivityType](index.md) / [SIMPLE](./-s-i-m-p-l-e.md)

# SIMPLE

`SIMPLE`

### Inherited Functions

| Name | Summary |
|---|---|
| [getTypeName](get-type-name.md) | `fun getTypeName(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!` |
