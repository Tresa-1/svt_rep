//[sdk](../../../../../index.md)/[com.robotemi.sdk.activitystream](../../../index.md)/[ActivityStreamObject](../../index.md)/[ActivityType](../index.md)/[SIMPLE](index.md)

# SIMPLE

[androidJvm]\
[SIMPLE](index.md)
