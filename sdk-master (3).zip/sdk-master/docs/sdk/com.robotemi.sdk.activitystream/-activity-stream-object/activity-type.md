//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[activityType](activity-type.md)

# activityType

[androidJvm]\

@Expose

@SerializedName(value = &quot;type&quot;)

open val [activityType](activity-type.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
