[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getSourceObject](./get-source-object.md)

# getSourceObject

`open fun getSourceObject(): `[`SourceObject`](../../com.robotemi.sdk/-source-object/index.md)`!`