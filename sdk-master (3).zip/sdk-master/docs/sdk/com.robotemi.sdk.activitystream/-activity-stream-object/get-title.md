[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getTitle](./get-title.md)

# getTitle

`open fun getTitle(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!`