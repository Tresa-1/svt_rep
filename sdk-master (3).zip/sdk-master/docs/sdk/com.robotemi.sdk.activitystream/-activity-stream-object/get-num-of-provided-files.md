[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getNumOfProvidedFiles](./get-num-of-provided-files.md)

# getNumOfProvidedFiles

`open fun getNumOfProvidedFiles(): `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)