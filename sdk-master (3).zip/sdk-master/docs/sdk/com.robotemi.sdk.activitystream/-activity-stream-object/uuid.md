//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[uuid](uuid.md)

# uuid

[androidJvm]\
open val [uuid](uuid.md): [String](https://docs.oracle.com/javase/8/docs/api/java/lang/String.html)
