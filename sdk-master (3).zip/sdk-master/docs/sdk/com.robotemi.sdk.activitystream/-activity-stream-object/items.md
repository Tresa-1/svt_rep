//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[items](items.md)

# items

[androidJvm]\

@Expose

@SerializedName(value = &quot;items&quot;)

open val [items](items.md): [List](https://docs.oracle.com/javase/8/docs/api/java/util/List.html)&lt;[ActivityStreamListItem](../-activity-stream-list-item/index.md)&gt;
