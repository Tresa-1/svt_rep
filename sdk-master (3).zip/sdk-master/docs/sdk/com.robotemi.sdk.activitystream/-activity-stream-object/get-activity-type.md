[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getActivityType](./get-activity-type.md)

# getActivityType

`open fun getActivityType(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!`