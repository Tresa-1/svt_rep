//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[sourceObject](source-object.md)

# sourceObject

[androidJvm]\

@Expose

@SerializedName(value = &quot;source&quot;)

open val [sourceObject](source-object.md): [SourceObject](../../com.robotemi.sdk/-source-object/index.md)
