//[sdk](../../../index.md)/[com.robotemi.sdk.activitystream](../index.md)/[ActivityStreamObject](index.md)/[CREATOR](-c-r-e-a-t-o-r.md)

# CREATOR

[androidJvm]\
val [CREATOR](-c-r-e-a-t-o-r.md): Parcelable.Creator&lt;[ActivityStreamObject](index.md)&gt;
