//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[Builder](index.md)/[addItem](add-item.md)

# addItem

[androidJvm]\
open fun [addItem](add-item.md)(@NonNullitem: [ActivityStreamListItem](../../-activity-stream-list-item/index.md)): [ActivityStreamObject.Builder](index.md)
