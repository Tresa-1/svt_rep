//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[Builder](index.md)/[media](media.md)

# media

[androidJvm]\
open fun [media](media.md)(@NonNullmediaObject: [MediaObject](../../../com.robotemi.sdk/-media-object/index.md)): [ActivityStreamObject.Builder](index.md)
