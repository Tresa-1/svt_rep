//[sdk](../../../../index.md)/[com.robotemi.sdk.activitystream](../../index.md)/[ActivityStreamObject](../index.md)/[Builder](index.md)/[source](source.md)

# source

[androidJvm]\
open fun [source](source.md)(@NonNullsourceObject: [SourceObject](../../../com.robotemi.sdk/-source-object/index.md)): [ActivityStreamObject.Builder](index.md)
