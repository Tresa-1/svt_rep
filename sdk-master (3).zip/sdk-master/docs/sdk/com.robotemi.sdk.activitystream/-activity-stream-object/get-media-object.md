[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getMediaObject](./get-media-object.md)

# getMediaObject

`open fun getMediaObject(): `[`MediaObject`](../../com.robotemi.sdk/-media-object/index.md)`!`