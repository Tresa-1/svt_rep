[sdk](../../index.md) / [com.robotemi.sdk.activitystream](../index.md) / [ActivityStreamObject](index.md) / [getDate](./get-date.md)

# getDate

`open fun getDate(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`!`