- Release local artifact

```
./gradlew clean sdk:publishToMavenLocal
```

- Snapshot or official release
```
./gradlew clean sdk:publish
```